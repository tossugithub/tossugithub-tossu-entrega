# Copyright 2018 ACSONE SA/NV
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

{
    "name": "Tossu ",
    "summary": """
        This module allow to add variant product based on rules""",
    "version": "16.0.1.0.0",
    "license": "AGPL-3",
    "author": "Kevin Daniel del camoi",
    "website": "kevindcisc@gmail.com",
    "depends": ["base","purchase","product","purchase_requisition","sale","delivery"],
    "data": [
        "security/ir.model.access.csv",
        "wizard/config_product_wizard.xml",
        "views/pruchase_requisition.xml",
        "views/purchase_order.xml",
        "views/sale_order.xml",
        "views/stock_picking_inh.xml"
        
        ],
}
