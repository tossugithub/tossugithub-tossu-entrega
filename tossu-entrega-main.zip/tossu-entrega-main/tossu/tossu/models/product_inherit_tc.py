# -- coding: utf-8 --
from odoo import models, fields, api
import logging
_logger = logging.getLogger(__name__)
import re

class ProductCl(models.Model):
    _inherit = 'product.product'

    def name_get(self):
        
        data = super().name_get()
        data_mod =[]
        for id, elemento in data:
            if ' ' in elemento:
                if '[' in elemento.split(' ', 1)[0]:
                        str_no_ref =elemento.split(' ', 1)[1]
                        data_final = self.procesar_string(str_no_ref)
                else:
                        str_no_ref = elemento
                        data_final = self.procesar_string(str_no_ref)
            else:
                data_final = elemento
                
            data_mod.append((id, data_final))
            
        return data_mod


    def procesar_string(self, input_string):
        patron = r'\((.*?)\)'
        match = re.search(patron, input_string)
        if match:
            contenido_parentesis = match.group(1)
            contenido_dividido = contenido_parentesis.split('-', 1)
            if len(contenido_dividido) > 1:
                contenido_procesado = contenido_dividido[0]
                nuevo_string = input_string.replace('(' + contenido_parentesis + ')', '(' + contenido_procesado + ')')
                return nuevo_string
        return input_string



        


        


