# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.
from . import purchase
from . import product_customer
from . import product_template
from . import purchase_requisition
from . import sale_order
from . import product_values
from . import product_inherit_tc
from . import model_export_prods
from . import model_export_lot



