# -- coding: utf-8 --
from odoo import models, fields, api
import logging
logger = logging.getLogger(__name__)
class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'
    
    def open_product_conf(self):
        compose_form = self.env.ref('tossu.config_product_wizard_purchase', raise_if_not_found=False)
        
        ctx = { 'default_purchase_id': self.id  }
        return {'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'config.product.wizard',
                'views': [(compose_form.id, 'form')],
                'view_id': False,
                'target': 'new',
                'context': ctx,
            }
