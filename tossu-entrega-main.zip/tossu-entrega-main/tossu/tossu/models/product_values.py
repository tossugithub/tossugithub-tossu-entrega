# -- coding: utf-8 --
from odoo import models, fields, api
import logging
logger = logging.getLogger(__name__)
class AtributeValueModColor(models.Model):
    _inherit = 'product.attribute.value'

    color_split = fields.Char(string='Color', required=False, compute='_compute_color_split')

    @api.depends('name')
    def _compute_color_split(self):
        for rec in self:
            if rec.name and rec.attribute_id.name == 'Color':
                rec.color_split = rec.name.split('-', 1)[0] if '-' in rec.name else rec.name
            else:
                rec.color_split = rec.name


