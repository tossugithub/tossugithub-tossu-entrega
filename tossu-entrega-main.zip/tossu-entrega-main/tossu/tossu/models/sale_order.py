# -- coding: utf-8 --
from odoo import models, fields, api
import logging
logger = logging.getLogger(__name__)
class SaleOrder(models.Model):
    _inherit = 'sale.order'

    id_prodSal = fields.Integer(string='ID prod y sal', copy=False, default=0, store=True)

    def open_product_conf(self):

        compose_form = self.env.ref('tossu.config_product_wizard_sale', raise_if_not_found=False)

        ctx = { 'default_sale_id': self.id  }
        return {'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'config.product.wizard',
                'views': [(compose_form.id, 'form')],
                'view_id': False,
                'target': 'new',
                'context': ctx,
            }


    @api.onchange('x_studio_many2one_field_t8EjK')
    def _assign_prod_sal(self):
        for record in self:
            if record.x_studio_many2one_field_t8EjK:
                record.id_prodSal = record.x_studio_many2one_field_t8EjK.id