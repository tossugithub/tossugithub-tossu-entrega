from odoo import models, fields, api
import logging
logger = logging.getLogger(__name__)

class PorductCustomer(models.Model):
    _name = 'product.customer'
    name = fields.Char("Nombre")