from io import BytesIO
from PIL import Image
from odoo import models, fields
import re
import logging
import base64
from datetime import datetime
import os
import json

_logger = logging.getLogger(__name__)

class PurchaseAggXlsxProd(models.AbstractModel):
    _name = 'report.tossu.report_bo_agg_prod'
    _inherit = 'report.report_xlsx.abstract'
    
    def generate_xlsx_report(self, workbook, data, blankets):

        prods = self.env['product.product'].search([('active','=',True)])
        report_name = 'Test'
        sheet = workbook.add_worksheet(report_name[:31])
        bold = workbook.add_format({'bold': False})
        sheet.write(0, 0, 'ID externo', bold)
        sheet.write(0, 1, 'Productos a comprar/ID externo', bold)
        sheet.write(0, 2, 'Foto', bold)
        line_number = 1
        for obj in prods:
            
            query = """
                         SELECT PC.product_product_id,
PC.product_template_attribute_value_id,
PA.name,
                                    PA.id ,
                                    PTAV.id as name_value_id,
                                    PTAV.name as name_value
                                    
                                FROM product_variant_combination as PC 
                                INNER JOIN product_product as P ON P.id = PC.product_product_id
                                INNER JOIN product_template_attribute_value as PTA ON PC.product_template_attribute_value_id = PTA.id
                                INNER JOIN product_attribute as PA ON PTA.attribute_id = PA.id
                                INNER JOIN product_attribute_value as PTAV ON PTA.product_attribute_value_id = PTAV.id
                                
                                where PC.product_product_id = %s and P.active = True;
            
                            """ 
            
            self._cr.execute(query % (obj.id) )
                    
            results = self._cr.fetchall()
    
            if obj.id:
                sheet.write(line_number, 0, obj.id, bold)

            #if obj.product_template_attribute_value_ids:
                #for attributes in obj.product_template_attribute_value_ids:
                    #if attributes.attribute_line_id.display_name == "Talla":
            for recs in results:
                if recs[2]['es_MX'] == 'Talla':
                    sheet.write(line_number, 2, recs[5]['es_MX'], bold)
                if recs[2]['es_MX'] == 'Color':                                
                    #if attributes.attribute_line_id.display_name == "Color":
                    cadena = recs[5]['es_MX']

                    if "-" in cadena:
                        color_pantone = cadena.split("-", 1)

                        pantone = color_pantone[1]
                        color = color_pantone[0]
                        
                        if pantone and pantone[0] == "-":
                            pantone = pantone[1:]
                            
                        if color:
                            sheet.write(line_number, 3, color, bold)
                    else:
                        sheet.write(line_number, 3, cadena, bold)

            if obj.product_customer:
                sheet.write(line_number, 4, obj.product_customer.name, bold)

            #if obj.product_customer:
                #sheet.write(line_number, 5, attributes.name, bold)

            
            if obj.sale_ok:
                sheet.write(line_number, 6, 'Producto terminado', bold)
            else:
                sheet.write(line_number, 6, 'Materia prima', bold)
                                
            sheet.write(line_number, 1, obj.name, bold)
            line_number = line_number + 1
                
