from io import BytesIO
from PIL import Image
from odoo import models, fields
import re
import logging
import base64
from datetime import datetime
import os
import json

_logger = logging.getLogger(__name__)

class PurchaseAggXlsxLot(models.AbstractModel):
    _name = 'report.tossu.report_bo_agg_lot'
    _inherit = 'report.report_xlsx.abstract'
    
    def generate_xlsx_report(self, workbook, data, blankets):

        report_name = 'Test'
        sheet = workbook.add_worksheet(report_name[:31])
        bold = workbook.add_format({'bold': False})
        sheet.write(0, 0, 'ID externo', bold)
        sheet.write(0, 1, 'Productos a comprar/ID externo', bold)
        sheet.write(0, 2, 'Producto qty', bold)
        sheet.write(0, 2, 'Nombre', bold)
        line_number = 1
        fecha_especifica = datetime(2024, 4, 5)

# Realizar la consulta usando el ORM de Odoo
        lots = self.env['stock.lot'].search([
            ('create_date', '>=', fecha_especifica.strftime('%Y-%m-%d 14:00:00')),
            ('create_date', '<=', fecha_especifica.strftime('%Y-%m-%d 23:59:59'))
        ])
        
        for obj in lots:
            
    
            if obj.id:
                sheet.write(line_number, 0, obj.id, bold)

            if obj.product_id:
                sheet.write(line_number, 1, obj.product_id.id, bold)

            if obj.product_qty:
                sheet.write(line_number, 2, obj.product_qty, bold)

            if obj.name:
                sheet.write(line_number, 3, obj.name, bold)

            line_number = line_number + 1
                
