# -- coding: utf-8 --
from odoo import models, fields, api
import logging
logger = logging.getLogger(__name__)

class PurchaseTemnplate(models.Model):
    _inherit = 'product.template'
    product_customer = fields.Many2one('product.customer',"Cliente")
    
class ProductProduct(models.Model):
    _inherit = 'product.product'
   


    product_template_variant_value_ids = fields.Many2many('product.template.attribute.value', relation='product_variant_combination',
                                                          domain=[], string="Variant Values", ondelete='restrict')