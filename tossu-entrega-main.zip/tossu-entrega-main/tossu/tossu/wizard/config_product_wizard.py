# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
import logging
import pytz
_logger = logging.getLogger(__name__)

class ConfigProductWizard(models.TransientModel):
    _name = "config.product.wizard"
    _description = "Product Label Wizard"
    
    #Default attributes wizard
    """
        *Must be taken from ir.congif.parameter
    """
    def _default_attribute_color(self):
        return self.env['product.attribute'].search([('name','=','Color')]).id
    def _default_attribute_label(self):
        return self.env['product.attribute'].search([('name','=','Etiqueta')]).id
    def _default_attribute_design(self):
        return self.env['product.attribute'].search([('name','=','Diseño')]).id
        
    #MANDATORY FIELDS
    company_id = fields.Many2one(
        related='purchase_id.company_id', store=True, index=True)
    purchase_requisition = fields.Many2one('purchase.requisition')
    purchase_id = fields.Many2one('purchase.order')
    sale_id = fields.Many2one('sale.order')
   
    #BASE DOMAINS 
    main_color_domain = fields.Many2many('product.attribute.value','main_color_domain_default_rel')
    main_label_domain = fields.Many2many('product.attribute.value','main_labels_domain_default_rel')
    main_design_domain = fields.Many2many('product.attribute.value','main_design_domain_default_rel')
    selected_products_domain = fields.Many2many('product.product','main_product_domain_model_default_rel')
    
    
    #BASE SELECTABLE FIELDS
    customer = fields.Many2one('product.customer',string="Cliente" )
    model_product = fields.Many2one('product.template', string="Producto" )
    color = fields.Many2many('product.attribute.value','main_color_default_rel',string="Color" )
    label = fields.Many2one('product.attribute.value',string="Etiqueta" )
    design = fields.Many2one('product.attribute.value',string="Diseño" )
    #selected_products = fields.Many2many('product.product','main_product_model_default_rel', "Modelos seleccionables")
    config_product_wizard_lines = fields.One2many('config.product.wizard.line','config_product_wizard_id')
    
    date_planned = fields.Datetime(
        string='Fecha prevista',
        default=lambda self: fields.Datetime.now(),
        copy=False, store=True, readonly=False,
    )
    #OVERRIDE METHOD'S
    @api.model
    def default_get(self, fields):
        rec = super(ConfigProductWizard, self).default_get(fields)
        return rec
    #ON CHANGE METHODS
    @api.onchange('customer')
    def _onchange_customer(self):
        self.model_product = False
        self.color = False
        self.label = False
        self.design = False
        self.selected_products_domain = False
        
        
    @api.onchange('model_product')
    def _onchange_model(self):
        attribute_color = self._default_attribute_color()
       
        attribute_label = self._default_attribute_label()
        attribute_design = self._default_attribute_design()
        attributes = [attribute_color,attribute_label,attribute_design]
        if attributes  and self.model_product :
            """
                This query allow the relation from attribute , values & product 
                it take all attributes related wizard and specific product template
                to retrieve all atribute values that will be used as domain in each case.
            """
            query = """
                        SELECT 
                        
                            PC.product_product_id,
                            PC.product_template_attribute_value_id,
                            PA.name,
                            PA.id ,
                            PTAV.id as name_value_id,
                            PTAV.name as name_value,
                            PTA.attribute_id as pta                
                        FROM product_variant_combination as PC 
                        INNER JOIN product_product as P ON P.id = PC.product_product_id
                        INNER JOIN product_template_attribute_value as PTA ON PC.product_template_attribute_value_id = PTA.id
                        INNER JOIN product_attribute as PA ON PTA.attribute_id = PA.id
                        INNER JOIN product_attribute_value as PTAV ON PTA.product_attribute_value_id = PTAV.id
                        where    PA.id in %s and  P.product_tmpl_id = %s and P.active = True;
       
                    """ 
            #CLEAN DOMIANS
            self.main_color_domain = False
            self.main_label_domain = False
            self.main_design_domain = False
            self._cr.execute(query % ( tuple(attributes), self.model_product.id ) )
            results = self._cr.fetchall()
            """
                These variables matches with the last query 
                compare index 4 (attribute value) with attribute qizard.
                get all avaible attribute-values
            """
            #color
            values_attributes = [x[4] for x in results if x[6] == attribute_color ]
            self.main_color_domain = values_attributes
            
            #label
            values_attributes = [x[4] for x in results if x[6] == attribute_label ]
            self.main_label_domain = values_attributes
            
            #design
            values_attributes = [x[4] for x in results if x[6] == attribute_design ]
            self.main_design_domain = values_attributes

            #Clean selectable values
            self.color = False
            self.label = False
            self.design = False
            self.selected_products_domain = False
            #self.selected_products = False
            
    @api.onchange('color','label','design')        
    def domain_product_selected(self):
            #Prepare all attributes selected , design is not often present
            attribute_color = self.color.ids
            attribute_label = [self.label.id]
            attribute_design = [self.design.id]
            
            attributes = [attribute_color,attribute_label]
            if self.design:
                attributes += [attribute_design]
            condition =  attributes  and self.model_product  and  self.color.ids and self.label.id
            if condition or ( condition and  self.design.id ) :
                records_avaible = []
                products = ""
                """
                    This query find all products related with de attributes selected
                    then store those products as local variable
                    then use those products in every query 
                    to guarante next attribute matches or cotain the last attribute
                    by relation of those products.
                """
                for x in attributes:
                    if x: 
                        if records_avaible:
                            products = """and PC.product_product_id in %s""" % (str(tuple(  records_avaible if len(records_avaible) > 1 else records_avaible+records_avaible  )) ) 
                        query = """
                                SELECT 
                                
                                    PC.product_product_id,
                                    PC.product_template_attribute_value_id,
                                    PA.name,
                                    PA.id ,
                                    PTAV.id as name_value_id,
                                    PTAV.name as name_value
                                    
                                FROM product_variant_combination as PC 
                                INNER JOIN product_product as P ON P.id = PC.product_product_id
                                INNER JOIN product_template_attribute_value as PTA ON PC.product_template_attribute_value_id = PTA.id
                                INNER JOIN product_attribute as PA ON PTA.attribute_id = PA.id
                                INNER JOIN product_attribute_value as PTAV ON PTA.product_attribute_value_id = PTAV.id
                                
                                where   P.product_tmpl_id = %s and PTAV.id in %s %s and P.active = True;
            
                            """ 
                        _logger.info(x)
                        self._cr.execute(query % ( self.model_product.id,  tuple(x if len(x)> 1 else x +x ),products) )
                    
                        results = self._cr.fetchall()
                        records_avaible = [x[0] for x in results]
                 
                # Add products that matches with all atribute selected
                if records_avaible:
                    self.selected_products_domain = records_avaible
                    
            else:
                #self.selected_products = False
                self.selected_products_domain = False

    #BUTTONS
    def add_products_lines(self):
           
            if self.selected_products_domain:
                self.config_product_wizard_lines = [ 
                                                (0,0,{
                                                    'config_product_wizard_id':self.id,
                                                    'product_id':x.id,
                                                    'product_uom_qty': 0 ,
                                                    'product_price': 0,
                                                    'date_planned': self.date_planned
                                                
                                                })
                                                for x in self.selected_products_domain  ]
            if self.sale_id:
                compose_form = self.env.ref('tossu.config_product_wizard_sale', raise_if_not_found=False)
            else:
                compose_form = self.env.ref('tossu.config_product_wizard_purchase', raise_if_not_found=False)

            return {
                    'view_mode': 'form',
                    'res_model': 'config.product.wizard',
                    'type': 'ir.actions.act_window',
                    'views': [(compose_form.id, 'form')],
                    'res_id': self.id,
                    'target': 'new',
                    }           
    
    
    def remove_lines(self):
        if self.sale_id:
            compose_form = self.env.ref('tossu.config_product_wizard_sale', raise_if_not_found=False)
        else:
            compose_form = self.env.ref('tossu.config_product_wizard_purchase', raise_if_not_found=False)
        self.config_product_wizard_lines = False    
        return {
                
                'view_mode': 'form',
                'res_model': 'config.product.wizard',
                'type': 'ir.actions.act_window',
                'views': [(compose_form.id, 'form')],
                'res_id': self.id,
                'target': 'new',
            } 

    
    def do_action_keep(self):
        if self.sale_id:
            compose_form = self.env.ref('tossu.config_product_wizard_sale', raise_if_not_found=False)
        else:
            compose_form = self.env.ref('tossu.config_product_wizard_purchase', raise_if_not_found=False)
        self.do_action()
        self.config_product_wizard_lines = False    
        return {
                
                'view_mode': 'form',
                'res_model': 'config.product.wizard',
                'type': 'ir.actions.act_window',
                'views': [(compose_form.id, 'form')],
                'res_id': self.id,
                'target': 'new',
            } 
    def do_action(self):
        #This wizzard are compatible with PO , PA and SO
        config_product_wizard_lines = self.config_product_wizard_lines.filtered(lambda x: x.product_uom_qty > 0)
        if self.purchase_id:
            self.purchase_id.order_line = [ 
                                                (0,0,{
                                                    'product_uom': x.product_uom_id.id,
                                                    'product_id':x.product_id.id,
                                                    'product_qty':  x.product_uom_qty,
                                                    'price_unit': x.product_price,
                                                    'date_planned': x.date_planned
                                                })
                                                for x in config_product_wizard_lines  ]
            
        if self.purchase_requisition:
            user_tz = self.env.user.tz or self.env.context.get('tz')
            user_tz = pytz.timezone(user_tz) if user_tz else pytz.utc
            self.purchase_requisition.line_ids = [ 
                                                (0,0,{
                                                    'product_uom_id': x.product_uom_id.id,
                                                    'product_id':x.product_id.id,
                                                    'product_qty': x.product_uom_qty,
                                                    'price_unit': x.product_price,
                                                    'schedule_date': x.date_planned.astimezone(user_tz).replace(tzinfo=None).date()
                                                })
                                                for x in config_product_wizard_lines  ]
            
        if self.sale_id:     
            self.sale_id.order_line = [ 
                                                (0,0,{
                                                    'product_uom': x.product_uom_id.id,
                                                    'product_id':x.product_id.id,
                                                    'product_uom_qty':  x.product_uom_qty,
                                                    'price_unit': x.product_price
                                                })

                                                for x in config_product_wizard_lines  ]
            #Force trigger pricelist set
            #if len(self.sale_id.order_line) == len(self.sale_id.order_line.mapped(lambda x: x.price_unit == 0)):
             #   self.sale_id._recompute_prices()   
              #  self.sale_id.show_update_pricelist = True           
            





                

                                                
   
