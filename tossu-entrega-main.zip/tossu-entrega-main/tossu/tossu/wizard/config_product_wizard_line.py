# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import UserError
import re
#Model used as line(s), to prepare products by domain wiard
#Logic taken from sale.template
class SaleOrderTemplateLine(models.TransientModel):
    _name = "config.product.wizard.line"
    _description = "Quotation Template Line"
    _order = 'config_product_wizard_id, sequence, id'

    _sql_constraints = [
        ('accountable_product_id_required',
            "CHECK(display_type IS NOT NULL OR (product_id IS NOT NULL AND product_uom_id IS NOT NULL))",
            "Missing required product and UoM on accountable sale quote line."),

        ('non_accountable_fields_null',
            "CHECK(display_type IS NULL OR (product_id IS NULL AND product_uom_qty = 0 AND product_uom_id IS NULL))",
            "Forbidden product, quantity and UoM on non-accountable sale quote line"),
    ]

    config_product_wizard_id = fields.Many2one(
        comodel_name='config.product.wizard',
        index=True, required=True,
        ondelete='cascade')
    sequence = fields.Integer(
        string="Sequence",
        help="Gives the sequence order when displaying a list of sale quote lines.",
        default=10)

    company_id = fields.Many2one(
        related='config_product_wizard_id.company_id', store=True, index=True)

    product_id = fields.Many2one(
        comodel_name='product.product',
        check_company=True,
        domain="[('sale_ok', '=', True), ('company_id', 'in', [company_id, False])]")

    name = fields.Text(
        string="Description",
        compute='_compute_name',
        store=True, readonly=False, precompute=True,
        required=True,
        translate=True)
    
    product_id_name = fields.Text(
        string="Product",
        compute='_compute_name_product',
        store=True, readonly=False, precompute=True,
        required=True,
        translate=True)

    product_uom_id = fields.Many2one(
        comodel_name='uom.uom',
        string="Unidadad de medida",
        compute='_compute_product_uom_id',
        store=True, readonly=False, precompute=True,
        domain="[('category_id', '=', product_uom_category_id)]")
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id')
    product_uom_qty = fields.Integer(
        string='Cantidad',
        required=True,
        digits='Product Unit of Measure',
        default=1)
    product_price = fields.Float(
        string='Precio',
        digits='Product Unit of Measure',
        default=0)

    display_type = fields.Selection([
        ('line_section', "Section"),
        ('line_note', "Note")], default=False)
    date_planned = fields.Datetime(
        string='Fecha prevista',
        default=lambda self: fields.Datetime.now(),
        copy=False, store=True, readonly=False,
    )

    #=== COMPUTE METHODS ===#

    @api.depends('product_id')
    def _compute_name(self):
        first_string = ''
        for option in self:
            if not option.product_id:
                continue
            if ' ' in option.product_id.get_product_multiline_description_sale():
                
                if '[' in option.product_id.get_product_multiline_description_sale().split(' ', 1)[0]:
                    first_string =option.product_id.get_product_multiline_description_sale().split(' ', 1)[1] 
                else:
                    first_string = option.product_id.get_product_multiline_description_sale()

                if first_string:
                     if '-' in first_string.split(' ', 1)[0]:
                        final_string = first_string.split('-', 2) if '-' in first_string else first_string
                        final_string = final_string[0]+"-"+final_string[1]
                     else:
                        final_string = first_string.split('-', 1)[0] if ' ' in first_string else first_string

                     if ')' in final_string:
                         option.name = final_string
                     else:   
                        option.name = final_string + ')'
            else:
                option.name = option.product_id.get_product_multiline_description_sale()
                return True

    @api.depends('product_id')
    def _compute_name_product(self):
        first_string = ''
        for option in self:
            if not option.product_id:
                continue

            option.product_id_name = option.product_id.get_product_multiline_description_sale()
            

    def procesar_string(self, input_string):
        patron = r'\((.*?)\)'
        match = re.search(patron, input_string)
        if match:
            contenido_parentesis = match.group(1)
            contenido_dividido = contenido_parentesis.split('-', 1)
            if len(contenido_dividido) > 1:
                contenido_procesado = contenido_dividido[0]
                nuevo_string = input_string.replace('(' + contenido_parentesis + ')', '(' + contenido_procesado + ')')
                return nuevo_string
        return input_string


    @api.depends('product_id')
    def _compute_product_uom_id(self):
        for option in self:
            option.product_uom_id = option.product_id.uom_id

    #=== CRUD METHODS ===#

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('display_type', self.default_get(['display_type'])['display_type']):
                vals.update(product_id=False, product_uom_qty=0, product_uom_id=False)
        return super().create(vals_list)

    def write(self, values):
        if 'display_type' in values and self.filtered(lambda line: line.display_type != values.get('display_type')):
            raise UserError(_("You cannot change the type of a sale quote line. Instead you should delete the current line and create a new line of the proper type."))
        return super().write(values)

