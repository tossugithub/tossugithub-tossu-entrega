# -*- coding: utf-8 -*-


{
    'name': 'Programa Clientes 1',
    
    'summary': """Programa clientes1""",
    
    'description': """
       App Clientes 1
        """,
    
    'author': 'Sergio',
    'category': 'manufacturing',
    'version': '0.1',
    'depends': ['base', 'stock','mrp', 'sale', 'product'],
    'data':[
        'security/ir.model.access.csv',
        'views/mrp_stock_clientes_view1.xml',
        ],
    
    'license': 'OPL-1'
}