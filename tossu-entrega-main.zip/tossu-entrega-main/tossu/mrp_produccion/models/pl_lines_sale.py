# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.tests import Form
from odoo.tools.misc import formatLang, format_date as odoo_format_date, get_lang
class PlLines(models.Model):
    
    _inherit = 'sale.order'

    def launch_pl_lines(self):
        existing_sale_ids = self.env['pl.lines10'].search([]).mapped('sale_id.id')

        # Search for sale orders with status 'sale' and not in existing_sale_ids
        sale_orders = self.env['sale.order'].search([
            ('state', '=', 'sale'),
            ('id', 'not in', existing_sale_ids)
        ])

        for order in sale_orders:
            product_temp_id = []
            # Iterate through each order line
            for line in order.order_line:
                if line.product_id.product_tmpl_id.id not in product_temp_id:
                    # Create a pl_lines record
                    self.env['pl.lines10'].create({
                                'product_template_id': line.product_id.product_tmpl_id.id,
                                'sale_id': order.id,
                                'x_studio_status': 'Por entregar'
                            })
                    product_temp_id.append(line.product_id.product_tmpl_id.id)




