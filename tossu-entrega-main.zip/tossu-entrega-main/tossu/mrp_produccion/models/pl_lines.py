# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.tests import Form
from odoo.tools.misc import formatLang, format_date as odoo_format_date, get_lang
class PlLines(models.Model):
    
    _name = 'pl.lines10'
    _description = 'Programa produccion'

    product_template_id = fields.Many2one('product.template', string='Template producto', readonly=True)
    
    sale_id = fields.Many2one('sale.order', string='Sale Order', readonly=True)

    disponibilidad = fields.Char(string='Disponibilidad')

    ubicacion = fields.Char(string='Ubicacion')

    name = fields.Char(string='Detalle')

    notas = fields.Char(string='Notas')

    cita = fields.Date(string='Cita')

    status = fields.Selection([
        ('', ''),  # Blank option
        ('por_entregar', 'Por entregar'),  # 'Por entregar' option
        ('entregado', 'Entregado')  # 'Entregado' option
    ], string='Estatus', default='', required=True)




