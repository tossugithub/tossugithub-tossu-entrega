{
    'name': 'Sales user groups',
    'version': '1.0',
    'author': 'Tecnicora',
    'summary': 'Genera los grupos para consultar ventas',
    'license': 'AGPL-3',
    'depends': ['base', 'stock','product','uom','barcodes','delivery','mrp','purchase','purchase_stock','sale','sale_stock'],  # List of dependencies
    'data': [
        'security/sales_users_security.xml',
        'security/ir.model.access.csv',
        'views/sales_users_views.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
