# -*- coding: utf-8 -*-
from odoo import models, fields
from odoo.exceptions import ValidationError, UserError
import base64
from odoo import _
import re
import csv
import io
import os.path
from datetime import datetime
import logging
import xlrd 
_logger = logging.getLogger(__name__)
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.tests import Form
from odoo.tools.misc import formatLang, format_date as odoo_format_date, get_lang
class PurchaseStockMassiveImport(models.Model):
    
    _name = 'purchase.stock.massive.import'
    _description = 'Purchase Massive Import'
    
    file = fields.Char(string='Nombre de importación', required=True, store=True, default='Nueva importación', readonly=True)
    status = fields.Selection(string='Estado',
                            selection=[
                                       ('new', 'Nuevo'),
                                       ('error', 'Error'),
                                       ('complet', 'Hecho'),
                                       ('complet_partial', 'Hecho con parcialidades'),
                                       ('revision', 'Validacion')],
                            copy=False, default='new',readonly=True)
    file = fields.Binary('Archivo excel', required=False)
    file_name = fields.Char(string='Nombre archivo', required=False)
    lot_id_ref = fields.Char(string='Embarque', required=False)
    
    purchase_ids = fields.Many2many('purchase.order', 'purchase_purchase_order_packing_default_rel',
        'multi_id', 'purchase_id', string='Ordenes de comora',
        )    
    purchase_count_ids = fields.Integer("Cantidad de compras",compute='_compute_purchase_count',)    
    move_ids = fields.Many2many('stock.picking', 'stock_move_packing_default_rel',
        'multi_id', 'move_id', string='Traslados')    
    move_count_ids = fields.Integer("Cantidad de movimientos",compute='_compute_move_count',)   

    name = fields.Char(string='Nombre', compute='_compute_name', store=True)

    def _compute_name(self):
        for record in self:
            record.name = record.lot_id_ref
            
    @api.onchange('lot_id_ref')
    def _onchange_lot_id_ref(self):
        for record in self:
            record.name = record.lot_id_ref

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('lot_id_ref'):
                vals.update(name= str(vals.get('lot_id_ref')))
        return super().create(vals_list)

    #buttons
    def action_open_purchase_orders(self):
        """ Return the list of purchase orders the approval request created or
        affected in quantity. """
        self.ensure_one()
        domain = [('id', 'in', self.purchase_ids.ids)]
        action = {
            'name': _('Ordenes de compra'),
            'view_type': 'tree',
            'view_mode': 'list,form',
            'res_model': 'purchase.order',
            'type': 'ir.actions.act_window',
            'context': self.env.context,
            'domain': domain,
        }
        return action
    def action_view_mo_delivery(self):
        """ Returns an action that display picking related to manufacturing order.
        It can either be a list view or in a form view (if there is only one picking to show).
        """
        self.ensure_one()
        """action = self.env["ir.actions.actions"]._for_xml_id("stock.action_picking_tree_all")
        if len(self.move_ids) > 1:
            action['domain'] = [('id', 'in', self.move_ids.ids)]
        elif self.move_ids:
            action['res_id'] = self.move_ids.id
            action['views'] = [(self.env.ref('stock.view_picking_form').id, 'form')]
            if 'views' in action:
                action['views'] += [(state, view) for state, view in action['views'] if view != 'form']
        action['context'] = dict(self._context, default_origin=self.file_name)"""

        domain = [('id', 'in', self.move_ids.ids)]
        action = {
            'name': _('Traslados'),
            'view_type': 'tree',
            'view_mode': 'tree',
            'res_model': 'stock.picking',
            'type': 'ir.actions.act_window',
            'domain': domain,
            'view_id': self.env.ref('multi_packing_receipt.view_packing_traslado_custom_list').id,
        }
        return action
    #computes
    @api.depends('purchase_ids')
    def _compute_purchase_count(self):
        for record in self:
            record.purchase_count_ids = 0
            if record.purchase_ids:
                record.purchase_count_ids = len(record.purchase_ids)
    @api.depends('move_ids')
    def _compute_move_count(self):
        for record in self:
            record.move_count_ids = 0
            if record.move_ids:
                record.move_count_ids = len(record.move_ids)
        
    #Validators
    def _validate_purchasee_order(self,col_datas):
        
        for p in col_datas:
              if not self.env['purchase.order'].search([('name','=', p.strip() )]):
                  raise ValidationError("Orden de compra no encontrada %s: " % p)

              po = self.env['purchase.order'].search([('name','=', p.strip() )])
            
              transit_incoming = self.env['stock.picking'].search([
                    ('origin', '=', str(po.name)),
                    ('picking_type_id', '=', 49)
                ])

              if transit_incoming:
                  for picking in transit_incoming:
                    picking.write({
                        'x_studio_embarque': str(self.lot_id_ref)
                    })
                      
        return col_datas  
    def _validate_default_code(self,col_datas):
        row = 1
        for p in col_datas:
                try:
                    if not self.env['product.product'].search([('default_code','=', str( int(p)   ).strip() )]):
                        raise ValidationError("Producto no encontrado %s: " % p)
                except:
                        raise ValidationError(" Producto formato erroneo %s  en linea %s: " % (p,row) ) 
                row += 1
        return col_datas
    def _validate_number_cel(self,col_datas,col_name):
        row = 1
        for partial in col_datas:
            try:
              partial = int(partial)
            except:
               raise ValidationError("%s erronea linea %s: " % (col_name,row) ) 
            row += 1 
        return col_datas
    def _validate_sequence_cel(self,col_datas):
        row = 1
        for d in col_datas:
           
            patron = r'^\d+(-\d+)?$'
            # Utilizando re.match para validar la cadena con el patrón
            if not re.match(patron, str(d).split(".")[0] ):
              raise ValidationError("Patron incorrecto en secuencia  %s en  linea %s: " % (str(d),row) ) 
            row += 1 
        return col_datas    
    def _validate_total_qty_package(self,qty_package,number_package,total):
        
        row = 1
        for x,y,z in zip(qty_package,number_package,total):
           
            if (int(x) * int(y)) != int(z):
                raise ValidationError("El total no coincide con la cantidad y numero de paquetes, rengon  %s: " % (row) ) 
            row += 1
    def _parse_xsl_to_joson(self,sheet):
        customers = ['A59','A99','A143','LEVY']
        shops = ['WALMART','COPPEL','MODULAR','COPPEL']
        data = []
        data_json = {
          'purchase_order':"",
          'partial':"",
          'default_code':"2",
          'model':"3",
          'color':"4",
          'pantone':"5",
          'design':"6",
          'size':"7",
          'qty_package':"",
          'number_package':"",
          'sequence_package':"",
          'total':""
        }
        
        self._validate_purchasee_order( sheet.col_values(0)[10:] )
        #self._validate_default_code( sheet.col_values(2)[10:] )
        self._validate_number_cel( sheet.col_values(1)[10:],"Parcialidad" )
        self._validate_number_cel( sheet.col_values(11)[10:],"piezas por bulto" )
        self._validate_number_cel( sheet.col_values(9)[10:],"cantidad de bultos" )
        self._validate_sequence_cel( sheet.col_values(10)[10:] )
        self._validate_number_cel( sheet.col_values(8)[10:],"Total" )
        
        self._validate_total_qty_package( sheet.col_values(11)[10:],sheet.col_values(9)[10:],sheet.col_values(8)[10:] )
    
        data_json = {}
        #GROUP BY PO

        for index_row in range(10, sheet.nrows):   
            data = sheet.row_values(index_row)
            #VARS NEEDED TO FOUND PRODUCT CODE
            #model_client = str(data[2])
            model_client = False
            name_one_customer = ''
            
            model = str(data[2])
            if not model:
                raise ValidationError("Modelo no indicado renglon %s " % ( index_row + 1 ) )
            if len(str(data[5])) > 0:
                color_expr = str(data[4])+"-"+str(data[5])
            else:
                color_expr = str(data[4])
            _logger.info(color_expr)
            color = self.env['product.attribute.value'].search( [('name','=', color_expr )] )
            if not color:
                raise ValidationError("Color no encontrado %s renglon %s : " % ( color ,index_row + 1 ) )
            _logger.info('LineaColor')
            _logger.info(index_row + 1)
            _logger.info(str(color))
            _logger.info('ColorExpress')
            _logger.info(str(color_expr))

            color = color.id
            design = self.env['product.attribute.value'].search( [('name','=', str(data[6])  ),('attribute_id.name','=','Diseño')] ) 
            design = design.id if self.env['product.attribute.value'].search( [('name','=', str(data[6])  )] ) else False
            size =  self.env['product.attribute.value'].search( [('name','=', str(data[7]).split(".")[0]),('attribute_id.name','=','Talla')] )
            if not size:
                raise ValidationError("Talla no encontrado %s renglon %s : " % ( str(data[7]).split(".")[0] ,index_row + 1  ) )
            size = size.id

            customer = self.env['purchase.order'].search([('name','=',str(data[0]))])
            if customer:
                name_customer = customer.partner_id.name

                for indice, valor in enumerate(customers):
                    position = name_customer.find(valor)
                    if position != -1:
                        name_one_customer = shops[indice]
                        break;
            
            #FOUND PRODUCT CODE
            default_code = self._get_defualt_code(model_client,model,color,design,size,index_row,name_one_customer) 
            
            if data[0]  in  data_json:
                data_json[data[0]]['datas'] += [{
                            'purchase_order':data[0],
                            'partial':data[1],
                            'default_code': int(default_code),
                            'qty_package':data[11],
                            'number_package':data[9],
                            'sequence_package':data[10],
                            'total':data[8]
                            }]
            else:
                data_json[data[0]] = {}
                data_json[data[0]]['datas'] = [{
                            'purchase_order':data[0],
                            'partial':data[1],
                            'default_code': int(default_code),
                            'qty_package':data[11],
                            'number_package':data[9],
                            'sequence_package':data[10],
                            'total':data[8]
                            }]
        validtae_json_moves = {}    
        #GROUPED PO GROUP DEFAULT CODES with total
        for key in data_json.keys():
            validtae_json_moves[key] = {}
            codes = {} 
            for data in data_json[key]['datas']:
                if  data['default_code'] in codes :
                    codes[data['default_code']] += data['total']
                else:
                    codes[data['default_code']] = data['total']
            validtae_json_moves[key] = codes 
        
        return data_json,validtae_json_moves
    #Buttons
    def import_excel(self):        
            self.ensure_one()
            columnas_esperadas = ["PO","Parcialidad","Referencia","Modelo","Color","Pantone","Diseño","Talla","Cantidad", "Numero","consecutivo","total"]
            xlsx_base64 = base64.b64decode(self.file)
            workbook = xlrd.open_workbook(file_contents=xlsx_base64)
            sheet = workbook.sheet_by_index(0)
            # Lista para almacenar índices de columnas con datos
            columnas_con_datos = []
            for i in range(0,11):
                if len( sheet.row_values(9)[i] ) > 0: 
                    columnas_con_datos.append(i)
            if len(columnas_con_datos)  != 11:
              raise ValidationError("Columnas insuficientes")
            json_data,validtae_json_moves = self._parse_xsl_to_joson(sheet)
            stock_picking = self._create_po_moves(json_data,validtae_json_moves)
            if str(self.status) == "complet_partial" or str(self.status) == "complet":

                return {
                            'name': 'Hecho',
                            'type': 'ir.actions.act_window',
                            'view_type': 'form',
                            'view_mode': 'form',
                            'res_model': 'custom.pop.message',
                            'target':'new',
                            'context':{'default_name':"Realizado con éxito" if str(self.status) == "complet" else "Hecho con parcialidades"} 
                            }
    #Privates
    def _create_po_moves(self,json_data,validtae_json_moves):
        for po in validtae_json_moves.keys():
            po_record = self.env['purchase.order'].search([  ('name','=', po ) ])
            
            stock_picking = po_record.picking_ids.filtered(lambda x: x.state == 'confirmed' or x.state == 'assigned')
            if not stock_picking:
                raise ValidationError("Sin traslados disponibles : %s " % (po) ) 
            #Always take 1
            stock_picking = stock_picking[0]
            moves_po = stock_picking.move_ids_without_package
            
            products_qty = {}
            #Retrie all product from move po
            for move in moves_po:
                if move.product_id.id in products_qty:
                    products_qty[move.product_id.id] += move.product_uom_qty
                else:
                    products_qty[move.product_id.id] = move.product_uom_qty
            _logger.info("Productos transferencia dict = 'id_producto': cantidad ")                
            _logger.info(products_qty)
            for p in validtae_json_moves[po].keys():
                #compare "keys" are code products
                if p not in products_qty:
                    #no encontro producto en la linea de PO
                    product_found = self.env['product.product'].search([('id','=',int(p) )])
                    products_found = self.env['product.product'].search([('id','in',products_qty.keys() )])
                    products_found = ",".join(products_found.mapped('name'))
                    raise ValidationError("Producto no encontrado  : %s  id: %s en  %s productos disponibles %s" % (product_found.name,product_found.id,po,products_found) )
                #respective 'code':qty compare
                #if products_qty[p] < validtae_json_moves[po][p]:
                #    #Supero la cantidad esperada
                #   raise
            #Erease moves
            stock_picking.move_line_ids.unlink()
            stock_picking_ref = self._prepare_ids_without_package_ref(stock_picking)
            new_packages = {}
            package_obj = self.env['stock.quant.package'].sudo()
            mov_to_write = []

            for data in json_data[po]['datas']:              
                product_id = self.env['product.product'].search([('id','=',int(data['default_code']) )])
                loc_id =  stock_picking.location_id.id
                dest_id = stock_picking.location_dest_id.id
                qty_package = int(data['qty_package'])
                product_uom_id = product_id.uom_id.id
                if '-' in  str(data['sequence_package']).split(".")[0] :
                    inicio, fin = map(int, data['sequence_package'].split('-')  )
                    rango_numeros = range(inicio, fin + 1)    
                    for package_seq in rango_numeros:
                        if  package_seq not in new_packages:
                            new_packages[package_seq] = package_obj.create({})
                        package = new_packages[package_seq].id
                        to_write_moves,stock_picking_ref = self._set_move_id_move_line_ids(product_id,loc_id,dest_id,package,product_uom_id,qty_package,stock_picking_ref)
                
                        mov_to_write += to_write_moves
                   
                else:
                    package_seq = int(data['sequence_package'])
                    if package_seq  not in new_packages:
                            new_packages[package_seq] = package_obj.create({})    
                            package = new_packages[package_seq].id          
                    to_write_moves,stock_picking_ref = self._set_move_id_move_line_ids(product_id,loc_id,dest_id,package,product_uom_id,qty_package,stock_picking_ref)
                    mov_to_write += to_write_moves

            if self.lot_id_ref:
                stock_picking.write({ 'move_line_ids': mov_to_write, 'x_studio_embarque': str(self.lot_id_ref) }  )
            else:
                stock_picking.write({ 'move_line_ids': mov_to_write  }  )
            stock_picking.move_ids_without_package.filtered(lambda x: x.product_id.id == product_id.id)
            
            backorder_wizard_dict = stock_picking.button_validate()
            if not isinstance(backorder_wizard_dict, bool):
                backorder_wizard = Form(self.env[backorder_wizard_dict['res_model']].with_context(backorder_wizard_dict['context'])).save()
                backorder_wizard.process()
            self.purchase_ids = [(4,po_record.id)]
            self.move_ids = [ (4,x) for x in stock_picking.ids ]
        self.status = "complet_partial" if self.move_ids.filtered(lambda x: x.backorder_ids) else "complet"
    #METHOD REFS ORIGINAL DEMAND ON RECEIPT
    def _prepare_ids_without_package_ref(self,stock_picking):
            datas = []
            for x in  stock_picking.move_ids_without_package:
                datas +=  [ {
                    'move_id':x.id,             
                    'product_id':x.product_id.id,
                    'origin_qty':x.product_uom_qty,
                    'qty_done': 0
                } ]
            return datas
    #THIS METHOS MATCH MOVE_LINE DEMAND WITH  MOVE_WITHOUT PACKAGE WITH ORIGINAL DEMAND         
    def _set_move_id_move_line_ids(self,product_id,loc_id,dest_id,package,product_uom_id,qty_package,stock_picking_ref):
                current_qty = qty_package
                to_write = []
                #mov_without_package = MWP
                #CEHCK EACH REAL AVAILABILITY BY MOVE WUOUTH PACKAGE
                for mov_ref in stock_picking_ref:
                        #same product and quantity avaivable by MWP
                        if mov_ref['product_id'] == product_id.id and mov_ref['origin_qty'] > mov_ref['qty_done'] :
                            remaining =  mov_ref['origin_qty'] - mov_ref['qty_done']
                            #curent qty can be used with total  qty MWP 
                            if remaining >=  current_qty:
                                    mov_ref['qty_done'] += current_qty
                                    mov_line = (0, 0, {
                                        'product_id': product_id.id,
                                        'location_id': loc_id,
                                        'location_dest_id': dest_id,
                                        'result_package_id':package,
                                        'lot_name':self.lot_id_ref,
                                        'product_uom_id':  product_uom_id,
                                        'qty_done': current_qty,
                                        'move_id': mov_ref['move_id'] 
                                            })
                                    to_write.append(mov_line)
                                    current_qty = 0    
                                    break              
                            #If remainign avaible , increase qty_done and reduce current_qty ,
                            elif remaining > 0 :
                                    current_qty = current_qty - remaining
                                    mov_ref['qty_done'] += remaining
                                    #Remaining is qty done in this case
                                    mov_line = (0, 0, {
                                        'product_id': product_id.id,
                                        'location_id': loc_id,
                                        'location_dest_id': dest_id,
                                        'result_package_id':package,
                                        'product_uom_id':  product_uom_id,
                                        'qty_done': remaining,
                                        'lot_name':self.lot_id_ref,
                                        'move_id': mov_ref['move_id'] 
                                            })
                                    to_write.append(mov_line)
                #out of orignal IN
                if current_qty > 0:
                    
                    mov_line = (0, 0, {
                                        'product_id': product_id.id,
                                        'lot_name':self.lot_id_ref,
                                        'location_id': loc_id,
                                        'location_dest_id': dest_id,
                                        'result_package_id':package,
                                        'product_uom_id':  product_uom_id,
                                        'qty_done': current_qty,
                                            })
                    to_write.append(mov_line)

                                 
                return to_write,stock_picking_ref
    def _get_defualt_code(self,model_client,model,color,design,size,index_row,name_one_customer):
        _logger.info("modelo cliente,modelo,color,diseño,tamaño,talla,name_customer")
        _logger.info( model_client )
        _logger.info( model )
        _logger.info( color )
        _logger.info( design )
        _logger.info( size )
        _logger.info( index_row )
        _logger.info( name_one_customer )
        if design:
            attributes = [color,design,size]
        else:
            attributes = [color,size]
        product_template = model
        if name_one_customer != '':
            customer_name_query = """and PTC.name = '%s'""" % (str(name_one_customer))
        else:
            customer_name_query =  """ """
        
        records_avaible = []
        products = ""
        #LANG CAUSE ODOO STORE TRANSLATABLE FIELDS AS JSON
        lang = self.env.user.lang or get_lang(self.env).code
        #Search atribute by product , products founded are used to be filtered with new attribute 
        # of each attribute ( those product have the last attribute)
        for x in attributes:
                    if x: 
                        if records_avaible:
                            products = """and PC.product_product_id in %s""" % (str(tuple(  records_avaible if len(records_avaible) > 1 else records_avaible+records_avaible  )) ) 
                        query = """
                                SELECT 
                                    PC.product_product_id,
                                    PC.product_template_attribute_value_id,
                                    PA.name,
                                    PA.id ,
                                    PT.name as pt_name,
                                    PTC.name as ptc_name
                                FROM product_variant_combination as PC 
                                INNER JOIN product_product as P ON P.id = PC.product_product_id
                                INNER JOIN product_template as PT ON PT.id = P.product_tmpl_id
                                INNER JOIN product_customer as PTC ON PTC.id = PT.product_customer
                                INNER JOIN product_template_attribute_value as PTA ON PC.product_template_attribute_value_id = PTA.id
                                INNER JOIN product_attribute as PA ON PTA.attribute_id = PA.id
                                INNER JOIN product_attribute_value as PTAV ON PTA.product_attribute_value_id = PTAV.id
                                where   PT.name->>'%s' = '%s'  and  PTAV.id = %s %s %s and P.active = True ;
            
                            """ 
                        self._cr.execute(query % ( lang,product_template,x,products,customer_name_query) )
                        results = self._cr.fetchall()
                        records_avaible = [x[0] for x in results]
        _logger.info("ID PRODUCTO ( VARIANTE )")                
        _logger.info(records_avaible)
        if records_avaible:
            records_avaible = [x for x in set(records_avaible)]
           
        if not records_avaible  :
            raise ValidationError("Producto no encontrado %s renglon %s revisa cliente o modelo  " % ( model,index_row +1) )
        elif len(records_avaible) > 1  :
            raise ValidationError("Mas de un producto encontrado  %s renglon %s  cliente o modelo  " % ( model,index_row+1) )
        else:
            return str(self.env['product.product'].search([ ("id","=",records_avaible[0]) ] ).id)

