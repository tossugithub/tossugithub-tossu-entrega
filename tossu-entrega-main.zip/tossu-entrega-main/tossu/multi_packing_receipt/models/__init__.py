# -*- coding: utf-8 -*-

from . import purchase_stock_massive_import
#from . import stock_pick_inherit_emb
