from odoo import models,fields, api
from odoo.exceptions import UserError
from odoo.tools.translate import _
import logging
_logger = logging.getLogger(__name__)

class StockInherit(models.Model):
    _inherit = 'stock.picking'

    @api.model
    def write(self, values):

        if self.picking_type_id.id == 40 and self.state == "done":
            
            transit_incoming = self.env['stock.picking'].search([
                ('origin', '=', self.origin),
                ('picking_type_id', '=', 49)
            ])
            
            if len(transit_incoming) == 1:
                if self.x_studio_embarque:
                    transit_incoming.write({'x_studio_embarque': str(self.x_studio_embarque)})
                    
        return super(StockInherit, self).write(values)
        
        