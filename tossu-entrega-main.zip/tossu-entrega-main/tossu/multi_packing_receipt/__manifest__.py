# -*- coding: utf-8 -*-


{
    'name': 'Multi Packing Receipt',
    
    'summary': """Massive pre-fill lines""",
    
    'description': """
       Pre fill lines PO
        """,
    
    'author': 'Kevin',
    'category': 'Purchase',
    'version': '0.1',
    'depends': ['base', 'stock','purchase','purchase_stock'],
    'data':[
     
        'security/ir.model.access.csv',
        'views/massive_import_purchase_moves.xml',
        
        ],
    
    'license': 'OPL-1'
}