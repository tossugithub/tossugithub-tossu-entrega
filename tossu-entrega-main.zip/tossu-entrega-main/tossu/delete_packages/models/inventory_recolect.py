from odoo import models, api
import logging

_logger = logging.getLogger(__name__)
_logger.setLevel(logging.DEBUG)

class StockPicking(models.Model):
    _inherit = 'stock.picking'  # Heredar del modelo
  
    def button_validate(self):
        _logger.debug("Entrando al método button_validate")
        # Puedes acceder a move que son las líneas y realizar las modificaciones necesarias
        
        # Source location (92, 'CY/Cajas') , Destination location(100, 'CY/Racks')
        if self.location_id.id == 92 and self.location_dest_id.id == 100:
            for move in self:
                # el método unlink() lo que hace desvincular los campos que se encuentran relacionados.
                move.package_level_ids.unlink()
                move.package_level_ids_details.unlink()

                
        return super(StockPicking, self).button_validate()
