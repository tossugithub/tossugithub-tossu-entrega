from odoo import models,fields, api
import logging
from odoo.exceptions import ValidationError, UserError
_logger = logging.getLogger(__name__)

class PurchaseOrderLineHeredado(models.Model):
    _inherit = 'stock.quant.package'

    def _separate_string_characters(self, cadena, longitud):
        resultado = ""
        for caracter in cadena:
            if ord(caracter) > 127:
                hex_caracter = caracter.encode('utf-8').hex().upper()
                resultado += f"_{hex_caracter[:2]}_{hex_caracter[2:]}"
            else:
                resultado += caracter
        
        cadena = str(resultado)
        segmentos = [cadena[i:i+longitud] for i in range(0, len(cadena), longitud)]
    
        # Agregar "-" al final de cada segmento excepto en el último
        segmentos_con_guion = [segmento + '-' if len(segmento) == longitud and i < len(segmentos) - 1 else segmento for i, segmento in enumerate(segmentos)]
    
        # Agregar "pzas." al último segmento
        if segmentos_con_guion:
            segmentos_con_guion[-1] += "pzas."



        return segmentos_con_guion