from odoo import models,fields, api
import logging
import pytz
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, time, date
_logger = logging.getLogger(__name__)
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, format_amount, format_date, formatLang, get_lang, groupby

class PurchaseOrderLineHeredado(models.Model):
    _inherit = 'purchase.order.line'

    compute_comision = fields.Float(
        string='Comision Computed Field', compute='_compute_comision', readonly=False, store=True, required=False)



    def _compute_price_unit_and_date_planned_and_name(self):
        _logger.info("ENTRO AQUI-compute")
        res = super(PurchaseOrderLineHeredado, self)._compute_price_unit_and_date_planned_and_name()
        dates_list = False
        sellers = False
        order_id = False
        for record in self:
            if not record.product_id or record.invoice_lines or not record.company_id:
                continue
            paramtro = {'order_id': record.order_id}
            sellers = record.product_id._select_seller(
                    partner_id=record.partner_id,
                    quantity=record.product_qty,
                    date=record.order_id.date_order and record.order_id.date_order.date() or fields.Date.context_today(record),
                    uom_id=record.product_uom,
                    params=paramtro)
        
            
            if sellers.purchase_requisition_line_id.schedule_date:
                fecha = sellers.purchase_requisition_line_id.schedule_date
                fecha_final = datetime(int(fecha.year), int(fecha.month), int(fecha.day),6,0,0)
                record.date_planned = fecha_final
                
    @api.onchange('x_studio_precio_sin_comision')
    def _onchange_price_unit(self):
        for record in self:
            if record.order_id.x_studio_comision >= 0:
                record.price_unit = record.x_studio_precio_sin_comision * (1 + (record.order_id.x_studio_comision/100))
            

            
    @api.depends('x_studio_precio_sin_comision')  # Ajusta esta línea con las dependencias correctas para el nuevo campo.
    def _compute_comision(self):
        for record in self:
            # Lógica de cálculo para another_computed_field
            if record.order_id.x_studio_comision >= 0:
                record.price_unit = record.x_studio_precio_sin_comision * (1 + (record.order_id.x_studio_comision/100))
            
            
    @api.onchange('order_id.x_studio_comision')
    def _onchange_price_unit_comi(self):
        for record in self:
            if record.order_id.x_studio_comision >= 0:
                record.price_unit = record.x_studio_precio_sin_comision * (1 + (record.order_id.x_studio_comision/100))
            

 
           

                
                

