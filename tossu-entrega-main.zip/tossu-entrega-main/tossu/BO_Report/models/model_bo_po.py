from io import BytesIO
from PIL import Image
from odoo import models, fields
import re
import logging
import base64
from datetime import datetime, timedelta
import os
import json
import datetime
import pytz
import shutil
_logger = logging.getLogger(__name__)


class PurchaseBoggXlsx(models.AbstractModel):
    _name = 'report.bo_report.report_bo_bogg'
    _inherit = 'report.report_xlsx.abstract'
    def generate_xlsx_report(self, workbook, data, blankets):
        save_path = "/tmp"
        fecha_str_local = ""
        #Use to separate color and pantone
        patron = r'^([A-Za-zÁáÉéÍíÓóÚúÜü\s]+)(?![A-Za-zÁáÉéÍíÓóÚúÜü])'
        #data = self.env['purchase.order'].search([("id","=",blankets.id)],offset=0, limit=5).export_data(['id'])
        #nested_list = data['datas']
        tamano_imagen = (800,800)
        # Access the first element of the nested list
        #external_id = nested_list[0][0]
        external_id = blankets.id
        _logger.info("EXTERNAL ID: " + str(external_id))
        max_pack_num = False
        max_colum_size = 22
        is_packs = False
        self.borrar_contenido_carpeta(save_path) #limpia el almacenamiento temporal de imagenes antes del proceso
        try:
            for obj in blankets:
                report_name = obj.name
                sheet = workbook.add_worksheet(report_name[:31])
                formato_separador_miles = workbook.add_format({'num_format': '#,##0'})
                formato_centro = workbook.add_format({'align': 'center', 'valign': 'vcenter'})
                bold = workbook.add_format({'bold': False})
                bold_wrap= workbook.add_format({'bold': False, 'text_wrap': True})
                bold_color = workbook.add_format({'bold': False, 'bg_color': '#F4FF03', 'border': 1})
                bold_true = workbook.add_format({'bold': True})
                inicio_title = 6 #Inicio del nombre de las columnas
                sheet.write(inicio_title, 0, 'ID externo', bold_color)
                sheet.write(inicio_title, 1, 'Lineas del pedido/ID externo', bold_color)
                sheet.write(inicio_title, 2, 'Foto', bold_color)
                sheet.write(inicio_title, 3, 'Modelo', bold_color)
                sheet.write(inicio_title, 4, 'CODE', bold_color)
                sheet.write(inicio_title, 5, 'Color', bold_color)
                sheet.write(inicio_title, 6, 'Pantone', bold_color)
                sheet.write(inicio_title, 7, 'Diseño', bold_color)
                sheet.write(inicio_title, 8, 'Talla', bold_color)
                sheet.write(inicio_title, 9, 'PACK', bold_color)
                sheet.write(inicio_title, 10, 'Piezas', bold_color)
                sheet.write(inicio_title, 11, 'Total de Piezas', bold_color)
                sheet.write(inicio_title, 12, 'Origen', bold_color)
                sheet.write(inicio_title, 13, 'Categoría', bold_color)
                sheet.write(inicio_title, 14, 'Etiqueta', bold_color)
                sheet.write(inicio_title, 15, 'SKU1', bold_color)
                sheet.write(inicio_title, 16, 'SKU2', bold_color)
                sheet.write(inicio_title, 17, 'Delivery', bold_color)
                sheet.write(inicio_title, 18, 'Precio Unitario sin Comisión', bold_color)
                #Encabezados
                sheet.write(0, 2, 'Referencia Odoo', bold_true)
                sheet.write(0, 3, str(obj.name), bold)
                sheet.write(1, 2, 'Referencia de Proveedor', bold_true)
                sheet.write(1, 3, str(obj.partner_ref), bold)
                sheet.write(2, 2, 'Proveedor', bold_true)
                sheet.write(2, 3, str(obj.partner_id.name), bold)
                sheet.write(3, 2, 'Fecha de creación', bold_true)     
                fecha_original = obj.create_date
                zona_horaria_local = pytz.timezone('America/Mexico_City')
                # Convertir la fecha original a un objeto datetime con la zona horaria del servidor
                fecha_original.strftime("%d/%m/%Y")
                fecha_original = pytz.utc.localize(fecha_original) 
                # Convertir la fecha a la zona horaria local
                fecha_local = fecha_original.astimezone(zona_horaria_local)
                fecha_str_local = str(fecha_local)
                sheet.write(4, 2, 'Cliente', bold_true)
                if len(blankets.order_line) > 0:
                    if blankets.order_line[0].product_id.product_customer:
                        sheet.write(4, 3, str(blankets.order_line[0].product_id.product_customer.name), bold) #Campo cliente
                    else:
                        sheet.write(4, 3, "Ninguno", bold)
                else:
                        sheet.write(4, 3, "Ninguno", bold)
                    
                if " " in str(fecha_str_local):
                    fecha_divida = fecha_str_local.split(" ", 1)
                    fecha_comun = fecha_divida[0]
                    if "-" in fecha_comun:
                        dias_mes_anio = fecha_comun.split("-")
                        anio = dias_mes_anio[0]
                        mes = dias_mes_anio[1]
                        dia = dias_mes_anio[2]
                        sheet.write(3, 3, str(dia) + "/" + str(mes) + "/" + str(anio), bold)
                else:
                    sheet.write(3, 3, str(fecha_local), bold)

                #Anchos de columnas
                sheet.set_column(2,2,max_colum_size)#FOTO
                sheet.set_column(3,3,14.78)#Modelo
                sheet.set_column(13,13,11.78)#Categoria
                sheet.set_column(14,14,30.5)#Etiqueta
                sheet.set_column(17,17,20)#Delivery
                sheet.set_column(18,18,24.89)#Precio
                sheet.set_column(5,5,18.2)#Color
                
                
                #Columnas ocultas
                sheet.set_column("E:E", None, None, {'hidden': True})#CODE 4
                sheet.set_column("G:G", None, None, {'hidden': True})#Pantone 6
                sheet.set_column("H:H", None, None, {'hidden': True})#Diseño 7
                sheet.set_column("J:J", None, None, {'hidden': True})#Pack 9
                sheet.set_column("L:L", None, None, {'hidden': True})#Total piezas 11
                sheet.set_column("M:M", None, None, {'hidden': True})#Origen 12
                sheet.set_column("P:P", None, None, {'hidden': True})#SKU1 15
                sheet.set_column("Q:Q", None, None, {'hidden': True})#SKU2 16
                line_number = 7
                for lines in blankets.order_line:
                    product_image = lines.product_id.image_1920
                    name_img = os.path.join(save_path, 'imagen' + str(line_number) + '.png')
                    #name_img_to_delete= os.path.join(save_path, 'imagen' + str(line_number-1) + '.png')
                    if os.path.exists(name_img):
                        os.remove(name_img)
                    if external_id:
                        sheet.write(line_number, 0, str(external_id), bold)
                    if product_image:
                        
                        sheet.set_row(line_number,64)
                        decoded_data = base64.b64decode(product_image)
                        # Crea una imagen desde los datos binarios
                        image = Image.open(BytesIO(decoded_data))
                        #imagen_redimensionada = image.resize(tamano_imagen)
                        image.save(name_img)
                        anchura, altura = image.size
                        scale_x = 1 / anchura * 60
                        scale_y = 1 / altura * 60
                        
                        sheet.insert_image(line_number,2, name_img, {'x_offset': 20, 'y_offset': 20,"x_scale": scale_x, "y_scale": scale_y}) # establece la posicion de una sola imagen en la celda
                        
                    if lines.product_id.product_template_attribute_value_ids:
                        for attributes in lines.product_id.product_template_attribute_value_ids:
                            if attributes.attribute_line_id.display_name == "Talla":
                                sheet.write(line_number, 8, attributes.name, bold)
                            if attributes.attribute_line_id.display_name == "Etiqueta":
                                sheet.write(line_number, 14, attributes.name, bold)
                            if attributes.attribute_line_id.display_name == "Color":
                                cadena = attributes.name
                                coincidencia = re.match(patron, cadena)
        
                                if "-" in cadena:
                                    color_pantone = cadena.split("-", 1)
            
                                    pantone = color_pantone[1]
                                    color = color_pantone[0]
                                    
                                    if pantone and pantone[0] == "-":
                                        pantone = pantone[1:]
                                    
                                    if pantone:
                                        sheet.write(line_number, 6, pantone, bold_wrap)
                                        sheet.set_column("G:G", None, None, {'hidden': False})
                                        sheet.set_column(6,6,26.33)#PANTONE
                                        
                                    if color:
                                        sheet.write(line_number, 5, color, bold_wrap)
                                    
                                else:

                                    if not self.is_pack(cadena):
                                        sheet.write(line_number, 5, cadena, bold_wrap)
                                        
                                        
                                    if lines.product_id.bom_ids and self.is_pack(cadena):
                                        _logger.info("Es PACK")
                                        is_packs = True
                                        color_pack = ""
                                        color_pantone = ""
                                        num_components_pack = 0;
                                        line_number_pack = 0;
                                        x_offset = 0;
                                        ancho = 0;
                                        sheet.write(line_number, 4, cadena, bold)
                                        sheet.set_column("E:E", None, None, {'hidden': False})
                                        for bom in lines.product_id.variant_bom_ids:
                                            
                                            for component in bom.bom_line_ids: #Solo una lista de materiales

                                                """if len(bom.bom_line_ids) > 2:
                                                    if (8.5 * len(bom.bom_line_ids)) > max_colum_size :
                                                        max_colum_size = 8.5 * len(bom.bom_line_ids)
                                                    sheet.set_column(2,2, max_colum_size)"""
                                                
                                                num_components_pack += 1
                                                line_number_pack += 1
                                                """if component.product_id.image_1920:
                                                    name_img_pack = os.path.join(save_path, 'imagen' + str(line_number) + '_' + str(line_number_pack) + '.png')
                                                    sheet.set_row(line_number,64)
                                                    decoded_data = base64.b64decode(component.product_id.image_1920)
                                                        # Crea una imagen desde los datos binarios
                                                    image = Image.open(BytesIO(decoded_data))
                                                    #imagen_redimensionada = image.resize(tamano_imagen_pack)
                                                    image.save(name_img_pack)
                                                    anchura, altura = image.size
                                                    scale_x = 1 / anchura * 60
                                                    scale_y = 1 / altura * 60
                                                    sheet.insert_image(line_number,2, name_img_pack, {'x_offset': x_offset, 'y_offset': 20, "x_scale": scale_x, "y_scale": scale_y})
                                                    x_offset += 60;"""

                                                product_image = lines.product_id.image_1920
                                                name_img = os.path.join(save_path, 'imagen' + str(line_number) + '.png')
                                                #name_img_to_delete= os.path.join(save_path, 'imagen' + str(line_number-1) + '.png')
                                                if os.path.exists(name_img):
                                                    os.remove(name_img)
                                                if product_image:
                                                    
                                                    sheet.set_row(line_number,64)
                                                    decoded_data = base64.b64decode(product_image)
                                                    # Crea una imagen desde los datos binarios
                                                    image = Image.open(BytesIO(decoded_data))
                                                    #imagen_redimensionada = image.resize(tamano_imagen)
                                                    image.save(name_img)
                                                    anchura, altura = image.size
                                                    scale_x = 1 / anchura * 60
                                                    scale_y = 1 / altura * 60
                                                    
                                                    sheet.insert_image(line_number,2, name_img, {'x_offset': 20, 'y_offset': 20,"x_scale": scale_x, "y_scale": scale_y}) # establece la posicion de una sola imagen en la celda
                                                    
                                                if component.product_id.product_template_attribute_value_ids:                                               
                                                    for attributes in component.product_id.product_template_attribute_value_ids:
                                                        if attributes.attribute_line_id.display_name == "Color":
                                                            cadena = attributes.name
                                                            coincidencia = re.match(patron, cadena)
                                    
                                                            if "-" in cadena:
                                                                color_and_pantone = cadena.split("-", 1)
                                        
                                                                pantone = color_and_pantone[1]
                                                                color = color_and_pantone[0]
                                                                
                                                                if pantone and pantone[0] == "-":
                                                                    pantone = pantone[1:]
                                                                
                                                                if pantone:
                                                                    color_pantone = color_pantone + ", " + str(pantone)
                                                                    
                                                                if color:
                                                                    color_pack = color_pack + ", " + str(color)
    
                                                            else:
                                                                color_pack = color_pack + ", " + str(cadena)
                                                                
                                            break;                    
    
                                        if color_pack:
                                            color_pack = color_pack[2:]
                                            sheet.write(line_number, 5, color_pack, bold_wrap)
                                        else:
                                            sheet.write(line_number, 5, cadena, bold_wrap)  
                                            
                                        if color_pantone:
                                            color_pantone = color_pantone[2:]
                                            sheet.write(line_number, 6, color_pantone, bold_wrap)
                                            sheet.set_column("G:G", None, None, {'hidden': False})
                                            sheet.set_column(6,6,26.33)#PANTONE
                                            
                                        
                                        if num_components_pack:
                                            sheet.write(line_number, 9, num_components_pack, bold)#num components
                                            sheet.set_column("J:J", None, None, {'hidden': False})
                                            sheet.write(line_number, 11, num_components_pack*lines.product_qty, formato_separador_miles)#num components
                                            sheet.set_column("L:L", None, None, {'hidden': False})
                                            sheet.set_column(11,11,12.5)
                                    else :     
                                        sheet.write(line_number, 5, cadena, bold_wrap)
                        
                                
                            if attributes.attribute_line_id.display_name == "Diseño":
                                sheet.write(line_number, 7, attributes.name, bold)
                                sheet.set_column("H:H", None, None, {'hidden': False})
                    if lines.product_id.x_studio_origen:
                        sheet.write(line_number, 12, lines.product_id.x_studio_origen, bold)
                        sheet.set_column("M:M", None, None, {'hidden': False})
                    if lines.product_id.categ_id:
                        sheet.write(line_number, 13, lines.product_id.categ_id.name, bold)
                    if lines.x_studio_precio_sin_comision:
                        sheet.write(line_number, 18, lines.x_studio_precio_sin_comision, bold)
                    else:
                        sheet.write(line_number, 18, 0, bold)
                    if lines.product_id.name:
                        sheet.write(line_number, 3, lines.product_id.name, bold)
                    if lines.product_qty:
                        sheet.write(line_number, 10, lines.product_qty, formato_separador_miles)
                    if lines.date_planned:
                        fecha = fields.Datetime.from_string(lines.date_planned).date()
                        
                        fecha_formateada_delivery = fecha.strftime("%d/%m/%Y")
                        formato_fecha = workbook.add_format({'num_format': 'd/m/yyyy'})
    
                        sheet.write(line_number, 17, fecha, formato_fecha)
                    if lines.product_id.x_studio_sku_1_1:
                        sheet.write(line_number, 15, lines.product_id.x_studio_sku_1_1, bold)
                        sheet.set_column("P:P", None, None, {'hidden': False})
                        sheet.set_column(15,15,17)#SKU1
                    if lines.product_id.x_studio_sku_2_1:
                        sheet.write(line_number, 16, lines.product_id.x_studio_sku_2_1, bold)
                        sheet.set_column("Q:Q", None, None, {'hidden': False})
                        sheet.set_column(16,16,17)#SKU2
                    try:
                        id_line_product = lines.id
                        if id_line_product:
                            sheet.write(line_number, 1, str(id_line_product), bold)
                    except:
                        pass
                    if lines.product_id.product_customer.name == "COPPEL" and not is_packs:
                        sheet.write(line_number, 4, str(lines.product_id.x_studio_codigo_plantilla), bold)
                        sheet.set_column("E:E", None, None, {'hidden': False})
                    is_packs = False
                    line_number = line_number + 1
            sheet.set_column("A:B", None, None, {'hidden': True})
        except Exception as e:
            _logger.info(f"Error {e}")

            
    def borrar_contenido_carpeta(self, ruta_carpeta):
        try:
            if os.path.exists(ruta_carpeta):
                for elemento in os.listdir(ruta_carpeta):
                    ruta_elemento = os.path.join(ruta_carpeta, elemento)
                    if os.path.isfile(ruta_elemento):
                        os.unlink(ruta_elemento)
                    elif os.path.isdir(ruta_elemento):
                        shutil.rmtree(ruta_elemento)
                _logger.info(f"Contenido de {ruta_carpeta} eliminado con éxito.")

                print(f"Contenido de {ruta_carpeta} eliminado con éxito.")
            else:
                _logger.info(f"La carpeta {ruta_carpeta} no existe.")
                print(f"La carpeta {ruta_carpeta} no existe.")
        except Exception as e:
            _logger.info(f"Error al borrar el contenido de la carpeta: {e}")
            print(f"Error al borrar el contenido de la carpeta: {e}")
        

    def is_pack(self, cadena):
        try:
            id = int(cadena)
            return True
        except Exception as e:
            return False
