from odoo import models, fields, api

class PurchaseModel(models.Model):
    _inherit= "purchase.requisition"
    total_piezas = fields.Integer(compute="_compute_total_piezas",string='Total Piezas', copy=False, default=0, store=False)

    @api.depends('line_ids.product_qty')
    def _compute_total_piezas(self):
        for record in self:
            total_piezas = 0
            for line in record.line_ids:
                total_piezas += line.product_qty
            record.total_piezas = total_piezas
