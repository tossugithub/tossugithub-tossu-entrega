from odoo import models, fields, api

class SaleOrder(models.Model):
    _inherit= "sale.order"
    total_piezas = fields.Integer(compute="_compute_total_piezas",string='Total Piezas', copy=False, default=0, store=False)

    @api.depends('order_line.product_uom_qty')
    def _compute_total_piezas(self):
        for record in self:
            total_piezas = 0
            for line in record.order_line:
                total_piezas += line.product_uom_qty
            record.total_piezas = total_piezas
