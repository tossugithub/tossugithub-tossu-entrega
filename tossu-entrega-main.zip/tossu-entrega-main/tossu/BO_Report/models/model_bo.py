from io import BytesIO
from PIL import Image
from odoo import models, fields
import re
import logging
import base64
from datetime import datetime
import os
import json

_logger = logging.getLogger(__name__)

class PurchaseAggXlsx(models.AbstractModel):
    _name = 'report.bo_report.report_bo_agg'
    _inherit = 'report.report_xlsx.abstract'
    
    def generate_xlsx_report(self, workbook, data, blankets):
        save_path = "/tmp"
        #Use to separate color and pantone
        patron = r'^([A-Za-zÁáÉéÍíÓóÚúÜü\s]+)(?![A-Za-zÁáÉéÍíÓóÚúÜü])'
        data = self.env['purchase.requisition'].search([("id","=",blankets.id)],offset=0, limit=5).export_data(['id'])
        nested_list = data['datas']
        # Access the first element of the nested list
        external_id = nested_list[0][0]
        _logger.info("EXTERNAL ID: " + str(external_id))
        for obj in blankets:
            report_name = obj.name
            sheet = workbook.add_worksheet(report_name[:31])
            bold = workbook.add_format({'bold': False})
            sheet.write(0, 0, 'ID externo', bold)
            sheet.write(0, 1, 'Productos a comprar/ID externo', bold)
            sheet.write(0, 2, 'Foto', bold)
            sheet.write(0, 3, 'Modelo', bold)
            sheet.write(0, 4, 'Color (es)', bold)
            sheet.write(0, 5, 'Pantone (s)', bold)
            sheet.write(0, 6, 'Diseño', bold)
            sheet.write(0, 7, 'Talla', bold)
            sheet.write(0, 8, 'Productos a comprar/Cantidad', bold)
            sheet.write(0, 9, 'Origen', bold)
            sheet.write(0, 10, 'Categoría', bold)
            sheet.write(0, 11, 'Etiqueta', bold)
            sheet.write(0, 12, 'SKU1', bold)
            sheet.write(0, 13, 'SKU2', bold)
            sheet.write(0, 14, 'Delivery', bold)
            sheet.write(0, 15, 'Productos a comprar/Precio unitario', bold)
            sheet.set_column_pixels(0,14,128)
            line_number = 1
            for lines in blankets.line_ids:
                product_image = lines.product_id.image_128
                name_img = os.path.join(save_path, 'imagen' + str(line_number) + '.png')
                if os.path.exists(name_img):
                    os.remove(name_img)
                if external_id:
                    sheet.write(line_number, 0, str(external_id), bold)
                if product_image:
                    sheet.set_row_pixels(line_number,128)
                    decoded_data = base64.b64decode(product_image)
                    # Crea una imagen desde los datos binarios
                    image = Image.open(BytesIO(decoded_data))
                    image.save(name_img)
                    sheet.insert_image(line_number,2, name_img)
                if lines.product_id.product_template_attribute_value_ids:
                    for attributes in lines.product_id.product_template_attribute_value_ids:
                        if attributes.attribute_line_id.display_name == "Talla":
                            sheet.write(line_number, 7, attributes.name, bold)
                        if attributes.attribute_line_id.display_name == "Etiqueta":
                            sheet.write(line_number, 11, attributes.name, bold)
                        if attributes.attribute_line_id.display_name == "Color":
                            cadena = attributes.name
                            coincidencia = re.match(patron, cadena)
    
                            if coincidencia:
                                color = coincidencia.group(1)
                                pantone = re.sub(patron, '', cadena, count=1).strip()
                                # Si el primer carácter del "pantone" es un guion "-", se retira
                                if pantone and pantone[0] == "-":
                                    pantone = pantone[1:]
                                
                                if pantone:
                                    sheet.write(line_number, 5, pantone, bold)
                                    
                                if color:
                                    sheet.write(line_number, 4, color, bold)
                                
                            else:

                                if lines.product_id.bom_ids:
                                    color_pack = ""
                                    color_pantone = ""
                                    for bom in lines.product_id.variant_bom_ids:
                                        
                                        for component in bom.bom_line_ids:
                                            if component.product_id.product_template_attribute_value_ids:                                               
                                                for attributes in component.product_id.product_template_attribute_value_ids:
                                                    if attributes.attribute_line_id.display_name == "Color":
                                                        cadena = attributes.name
                                                        coincidencia = re.match(patron, cadena)
                                
                                                        if coincidencia:
                                                            color = coincidencia.group(1)
                                                            pantone = re.sub(patron, '', cadena, count=1).strip()
                                                            # Si el primer carácter del "pantone" es un guion "-", se retira
                                                            if pantone and pantone[0] == "-":
                                                                pantone = pantone[1:]
                                                            
                                                            if pantone:
                                                                color_pantone = color_pantone + " " + str(pantone)
                                                                
                                                            if color:
                                                                color_pack = color_pack + " " + str(color) 
                                                        

                                    if color_pack:
                                        sheet.write(line_number, 4, color_pack, bold)
                                    else:
                                        sheet.write(line_number, 4, cadena, bold)  
                                        
                                    if color_pantone:
                                        sheet.write(line_number, 5, color_pantone, bold)
                                        
                                    
                                            
                                else :     
                                    sheet.write(line_number, 4, cadena, bold)
                    
                            
                        if attributes.attribute_line_id.display_name == "Diseño":
                            sheet.write(line_number, 6, attributes.name, bold)
                if lines.product_id.x_studio_origen:
                    sheet.write(line_number, 9, lines.product_id.x_studio_origen, bold)
                if lines.product_id.categ_id:
                    sheet.write(line_number, 10, lines.product_id.categ_id.name, bold)
                if lines.price_unit:
                    sheet.write(line_number, 15, lines.price_unit, bold)
                if lines.product_id.name:
                    sheet.write(line_number, 3, lines.product_id.name, bold)
                if lines.product_qty:
                    sheet.write(line_number, 8, lines.product_qty, bold)
                if lines.product_id.x_studio_sku_1_1:
                    sheet.write(line_number, 12, lines.product_id.x_studio_sku_1_1, bold)
                if lines.product_id.x_studio_sku_2_1:
                    sheet.write(line_number, 12, lines.product_id.x_studio_sku_2_1, bold)
                if lines.schedule_date:
                    fecha = fields.Datetime.from_string(lines.schedule_date).date()
                    sheet.write(line_number, 14, str(fecha), bold)
                try:
                    external_id_product = lines.export_data(['id'])['datas'][0][0]
                    if external_id_product:
                        sheet.write(line_number, 1, str(external_id_product), bold)
                except:
                    pass
                line_number = line_number + 1
                
