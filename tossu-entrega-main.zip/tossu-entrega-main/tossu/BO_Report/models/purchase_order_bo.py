
from odoo import models,fields, api
import logging
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, time, date
_logger = logging.getLogger(__name__)
import base64
import io
from odoo import _
import openpyxl
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, format_amount, format_date, formatLang, get_lang, groupby
from odoo.addons.purchase.models.purchase import PurchaseOrder


class MiModeloHeredados(models.Model):
    _inherit = 'purchase.order'

    total_piezas = fields.Integer(compute="_compute_total_piezas",string='Total Piezas', copy=False, default=0, store=False)

    x_studio_comision = fields.Float(string='Comisión %', copy=False, default=0, store=True, readonly=False)

    file = fields.Binary('Excel Archivo', required=False)
    
    file_name = fields.Char("Nombre de archivo")

    total_piezas = fields.Integer(compute="_compute_total_piezas",string='Total Piezas', copy=False, default=0, store=False)

    @api.onchange('date_planned')
    def onchange_date_planned(self):
        _logger.info("ENTRO AQUI ONCHANGE")
    
    @api.onchange('currency_id')
    def onchange_partner(self):
        _logger.info("ENTRO AQUI ONCHANGE")
    
    @api.depends('order_line.product_qty')
    def _compute_total_piezas(self):
        for record in self:
            total_piezas = 0
            for line in record.order_line:
                total_piezas += line.product_qty
            record.total_piezas = total_piezas

    def process_po_file(self):

        if self.state == 'done' or self.state == 'cancel':
            raise UserError(_("La orden de compra se encuentra hecha o cancelada"))

        columnas_esperadas = [ "ID externo","Lineas del pedido/ID externo",  "Foto","Modelo","CODE", "Color","Pantone","Diseño", "Talla", "PACK", "Piezas", "Total de Piezas", "Categoría", "Etiqueta", "SKU1", "SKU2", "Delivery", "Precio Unitario sin Comisión"]

        cell_value_price = 18
        cell_value_piezas = 10
        cell_value_delivery = 17
        row_count = 0
        row_data_start = 8
        row_title_start = 7
        
        for record in self:

            if not record.file:
                raise UserError(_("Debes agregar un xlsx."))
                
            decoded_xlsx = base64.b64decode(record.file)
    
            # Crear un objeto de archivo en memoria
            xlsx_file = io.BytesIO(decoded_xlsx)
            
            # Cargar el libro de trabajo con openpyxl
            workbook = openpyxl.load_workbook(xlsx_file)
            
            # Acceder a una hoja de cálculo específica (por ejemplo, la primera hoja)
            sheet = workbook.active

            encabezados = [cell.value for cell in sheet[row_title_start]]#fila de inicio de los titulos de cada columna

            # Verificar si todas las columnas esperadas están presentes
            if all(columna_esperada in encabezados for columna_esperada in columnas_esperadas):
                
                for row in sheet.iter_rows():

                    if row_count >= row_data_start - 1:

                        
                        state_integrity = self._verify_integrity_data(row[0].value, row[1].value, row[cell_value_price].value, row[cell_value_piezas].value, row[cell_value_delivery].value,row_count + 1)
                        if not state_integrity['status']:
                            raise UserError(_(state_integrity['message']))
                            return False
                                    
                    row_count += 1

                #Despues de verificar se realizan las actualizaciones
                row_count = 0  # Reiniciar el contador de filas
                for row in sheet.iter_rows():
                    if row_count >= row_data_start - 1:
                        self._update_order_lines_po(row[0].value, row[1].value, row[cell_value_piezas].value,  row[cell_value_price].value, fields.Datetime.from_string(row[cell_value_delivery].value), row_count + 1)
                    row_count += 1

                self.file=False;
                        
            else:
                raise UserError(_("Al menos una de las columnas esperadas no está presente en el archivo."))
                print("Al menos una de las columnas esperadas no está presente en el archivo.")
            
            # Procesar el contenido de la hoja de cálculo
            
        return True


    def _verify_integrity_data(self, id_po, id_po_line, po_line_price, po_line_qty, po_line_date, linea):

        id_po = self.convertir_a_entero(id_po, 'ID Externo', linea)

        if not id_po['status']:
            return id_po

        id_po_line = self.convertir_a_entero(id_po_line, 'Lineas del pedido/ID externo', linea)

        if not id_po_line['status']:
            return id_po_line

        price = self.convertir_a_flotante(po_line_price, 'Precio Unitario sin Comisión', linea)
        
        if not price['status']:
            return price

        qty = self.convertir_a_entero(po_line_qty, 'Piezas', linea)
        
        if not qty['status']:
            return qty

        date = self.verify_date(po_line_date, 'Delivery', linea)
        
        if not date['status']:
            return date
            
        if id_po:
            try:
                purchase_order = self.env['purchase.order'].browse(id_po['id'])
                
                if purchase_order:
                    if id_po_line['id'] in purchase_order.order_line.ids:
                        
                        return {
                                'message': 'Correcto',
                                'status': True             
                            }
                    else:
                        return {
                                'message': 'No existe el producto en la orden de compra en la linea: ' + str(linea),
                                'status': False             
                            }
                else:
                    return {
                                'message': 'No se encontró la orden en la linea: ' + str(linea),
                                'status': False             
                            }
            except Exception as e:
                _logger.info("Error en la linea: " + str(linea) + " MENSAJE: " + str(e))
                _logger.info(e)
                return {
                            'message': "Error en la linea: " + str(linea) + " MENSAJE: " + str(e),
                            'status': False             
                        }
            

    def convertir_a_entero(self, id_str, nombre_campo, linea):
        try:
            id = int(id_str)
            return {'status': True, 'id': id}
        except Exception as e:
            return {
                'message': f'{nombre_campo} no válido en la línea: {str(linea)}',
                'status': False
            }

    def convertir_a_flotante(self, id_str, nombre_campo, linea):
        try:
            id = float(id_str)
            return {'status': True, 'id': id}
        except Exception as e:
            return {
                'message': f'{nombre_campo} no válido en la línea: {str(linea)}',
                'status': False
            }

    def verify_date(self, id_str, nombre_campo, linea):
        try:
            id = fields.Datetime.from_string(id_str)
            return {'status': True, 'id': id}
        except Exception as e:
            return {
                'message': f'{nombre_campo} no válido en la línea: {str(linea)}',
                'status': False
            }

    def _update_order_lines_po(self, id_po, id_po_line, product_qty, price_unit, date, linea):
        if id_po:
            try:
                purchase_order = self.env['purchase.order'].browse(int(id_po))
                
                if purchase_order:
                    if int(id_po_line) in purchase_order.order_line.ids:
                        
                        order_line_to_update = purchase_order.order_line.filtered(lambda line: line.id == int(id_po_line))

                        if order_line_to_update:
                            #fecha_odoo = fields.Datetime.from_string(date)
                            
                            fecha_y_hora_especifica = datetime(date.year, date.month, date.day, 6, 0, 0)
                            order_line_to_update.write({'product_qty': product_qty, 'x_studio_precio_sin_comision': float(price_unit), 'date_planned': fecha_y_hora_especifica})
                            
                    
            except Exception as e:
                _logger.info("Error en la linea: " + str(linea) + " MENSAJE: " + str(e))
                _logger.info(e)
                return {
                            'message': "Error en la linea: " + str(linea) + " MENSAJE: " + str(e),
                            'status': False             
                        }
            
        
                

    @api.onchange('x_studio_comision')
    def _onchange_price_unit_comi(self):
        for record in self:
            if record.x_studio_comision >= 0:
                for line in record.order_line:
                    line.price_unit = line.x_studio_precio_sin_comision * (1 + (record.x_studio_comision/100))

    @api.model
    def _get_picking_type(self, company_id):

        data = super()._get_picking_type(company_id)
        if data:
            picking_type = self.env['stock.picking.type'].search([('id', '=', 40)]) #id pickig 
            if picking_type:
                data = picking_type[:1]

        return data

    @api.depends('order_line.product_qty')
    def _compute_total_piezas(self):
        for record in self:
            total_piezas = 0
            for line in record.order_line:
                total_piezas += line.product_qty
            record.total_piezas = total_piezas