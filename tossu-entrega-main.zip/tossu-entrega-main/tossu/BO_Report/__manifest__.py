# -*- coding: utf-8 -*-
{
    'name': 'Odoo BO',
    
    'summary': """Purchase app""",
    
    'description': """
        BO report
        """,
    
    'author': 'Defulfillment',
    'category': 'Reports',
    'version': '0.1',
    'depends': ['helpdesk', 'helpdesk_timesheet', 'crm', 'crm_enterprise', 'sale_management', 'documents', 'base_automation','purchase','report_xlsx','purchase_requisition'],
    'data':['reports/report_bo.xml',
            'views/purchase_requisition_inherit.xml',
            'views/sale_order_inherit_totalqty.xml',
            'views/purchase_order_inherit.xml',
        
           ],
    'license': 'OPL-1'
}