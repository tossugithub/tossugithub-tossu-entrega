# -*- coding: utf-8 -*-
from odoo import models, fields
from odoo.exceptions import ValidationError, UserError
import base64
from odoo import _
import re
import csv
import io
import os.path
from datetime import datetime
import logging
import xlrd 
_logger = logging.getLogger(__name__)
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.tests import Form
from odoo.tools.misc import formatLang, format_date as odoo_format_date, get_lang
class MrpClientes1(models.Model):
    
    _name = 'mrp.stock.clientes2'
    _description = 'Programa Clientes'
    _auto = False  # Important to prevent Odoo from trying to create a table
    

    product_template_name = fields.Char(string='Producto', required=False)

    referencia_cliente = fields.Char(string='Referencia de cliente', required=False)

    name = fields.Char(string='Orden de Venta', required=False)
    
    total_productions = fields.Integer(string='Total producir', required=False)

    total_quantity = fields.Float(string='Cantidad', required=False)

    customer = fields.Char(string='Cliente', required=False)

    location = fields.Char(string='Planta producción', required=False)

    date_start = fields.Date(string='Fecha producción', required=False)

    date_end = fields.Date(string='Fecha cancelación', required=False)

    state =  fields.Char(string='Estado', required=False)

    total_piezas =  fields.Integer(string='Total piezas', required=False)

    code =  fields.Char(string='Código', required=False)

    packs =  fields.Integer(string='Packs', required=False)

    disponibility =  fields.Char(string='Disponibilidad ', required=False)

    note =  fields.Char(string='Notas', required=False)

    fecha_entrega = fields.Date(string='Cita', required=False)

    sale_id =  fields.Integer(string='sale_id_note', required=False)

    product_template_id =  fields.Integer(string='pt_id_note', required=False)

    location_edit =  fields.Char(string='Ubicación', required=False)
    
    @api.model
    def init(self):
        try:
            self.env.cr.execute("""
            CREATE OR REPLACE VIEW mrp_stock_clientes2 AS
              SELECT
    ROW_NUMBER() OVER (ORDER BY so.name, pt.name) AS id,
    so.client_order_ref as referencia_cliente,
    so.name as name,
    pt.name->>'es_MX' as product_template_name,
    pt.id as product_template_id,
    so.id as sale_id,
    COUNT(DISTINCT mp.id) as total_productions,
    (select SUM(product_uom_qty) from sale_order_line where order_id = so.id limit 1) as total_quantity,
    COALESCE(pc.name, 'Ninguno') as customer,
    mpc1.planta as location,
    TO_DATE(
        EXTRACT(year FROM mp.date_planned_start)::TEXT || '-' ||
        EXTRACT(month FROM mp.date_planned_start)::TEXT || '-' ||
        EXTRACT(day FROM mp.date_planned_start)::TEXT,
        'YYYY-MM-DD'
    ) AS date_start,
    TO_DATE(
        EXTRACT(year FROM so.x_studio_fecha_de_cancelacion)::TEXT || '-' ||
        EXTRACT(month FROM so.x_studio_fecha_de_cancelacion)::TEXT || '-' ||
        EXTRACT(day FROM so.x_studio_fecha_de_cancelacion)::TEXT,
        'YYYY-MM-DD'
    ) AS date_end,
    mp.state as state,
    CASE
        WHEN COALESCE(pc.name, 'Ninguno') = 'COPPEL' THEN (select PTAV2.name as name from product_template_attribute_value as PTA2 
INNER JOIN product_attribute as PA2 ON PTA2.attribute_id = PA2.id
INNER JOIN product_attribute_value as PTAV2 ON PTA2.product_attribute_value_id = PTAV2.id where product_tmpl_id = pt.id AND PA2.name->>'es_MX' = 'Color' limit 1) ->> 'es_MX'
        ELSE ''
    END AS code,
        TO_DATE(
        EXTRACT(year FROM so.commitment_date)::TEXT || '-' ||
        EXTRACT(month FROM so.commitment_date)::TEXT || '-' ||
        EXTRACT(day FROM so.commitment_date)::TEXT,
        'YYYY-MM-DD'
    ) AS fecha_entrega,
    (select SUM(product_uom_qty) from sale_order_line where order_id = so.id limit 1) * (SELECT COUNT(*)
            FROM mrp_bom_line mbl
            INNER JOIN product_template pt2 ON mbl.product_tmpl_id = pt2.id
            INNER JOIN product_category pcat ON pt2.categ_id = pcat.id
            WHERE bom_id = (select mp12.bom_id from procurement_group as pg12
INNER JOIN mrp_production as mp12 ON pg12.name = mp12.origin
INNER JOIN product_product as pp22 ON mp12.product_id = pp22.id
INNER JOIN product_template as pt22 ON pp22.product_tmpl_id = pt22.id
where pg12.sale_id = so.id AND pt22.id = pt.id AND mp12.state = 'confirmed' limit 1) AND pcat.parent_id != 481) as total_piezas,
(
SELECT COUNT(*)
            FROM mrp_bom_line mbl
            INNER JOIN product_template pt2 ON mbl.product_tmpl_id = pt2.id
            INNER JOIN product_category pcat ON pt2.categ_id = pcat.id
            WHERE bom_id = (select mp12.bom_id from procurement_group as pg12
INNER JOIN mrp_production as mp12 ON pg12.name = mp12.origin
INNER JOIN product_product as pp22 ON mp12.product_id = pp22.id
INNER JOIN product_template as pt22 ON pp22.product_tmpl_id = pt22.id
where pg12.sale_id = so.id AND pt22.id = pt.id AND mp12.state = 'confirmed' limit 1) AND pcat.parent_id != 481
) as packs,
 (SELECT
   CASE
        WHEN EXISTS (
           WITH suma_by_prod AS (select sm3.product_id, SUM(sm3.product_uom_qty) as cantidad from sale_order so3 INNER JOIN mrp_production mp3 ON so3.name = mp3.origin 
INNER JOIN 
    stock_move sm3 ON mp3.name = sm3.name
INNER JOIN
    product_product pp3 ON sm3.product_id = pp3.id
INNER JOIN
    product_template pt3 ON pp3.product_tmpl_id = pt3.id
INNER JOIN
    product_category pcat3 ON pt3.categ_id = pcat3.id AND pcat3.parent_id != 481

 where so3.id = so.id AND sm3.raw_material_production_id = mp3.id
GROUP BY
    sm3.product_id)

SELECT sbp.product_id,COALESCE(SUM(sq2.quantity), 0) AS total_quantity,sbp.cantidad from suma_by_prod sbp 
LEFT JOIN
    stock_location sl2 ON sl2.active = True
LEFT JOIN
    stock_quant sq2 ON sbp.product_id = sq2.product_id AND sl2.id = sq2.location_id
GROUP BY
sbp.product_id,sbp.cantidad
HAVING
    COALESCE(SUM(sq2.quantity), 0) < sbp.cantidad ) THEN 'No disponible'
        ELSE 'Disponible'
    END AS estado) as disponibility,
mnc.note as note,
mlc2.location as location_edit

FROM
    mrp_production mp
INNER JOIN
    product_product pp ON mp.product_id = pp.id
INNER JOIN
    product_template pt ON pp.product_tmpl_id = pt.id
INNER JOIN
    product_customer pc ON pt.product_customer = pc.id
INNER JOIN
    stock_location sl ON mp.location_src_id = sl.id
INNER JOIN
    stock_location slp ON sl.location_id = slp.id
INNER JOIN product_variant_combination as PVC ON pp.id = PVC.product_product_id
INNER JOIN product_template_attribute_value as PTA ON PVC.product_template_attribute_value_id = PTA.id
INNER JOIN product_attribute as PA ON PTA.attribute_id = PA.id
INNER JOIN product_attribute_value as PTAV ON PTA.product_attribute_value_id = PTAV.id
INNER JOIN procurement_group as pg ON mp.origin = pg.name
INNER JOIN sale_order as so ON pg.sale_id = so.id
LEFT JOIN mrp_bom_line as mbl ON mp.bom_id = mbl.bom_id AND mbl.product_id = mp.product_id
LEFT JOIN stock_warehouse as sw ON sl.warehouse_id = sw.id
LEFT JOIN mrp_notes_clientes1 as mnc ON so.id = mnc.sale_id AND pt.id = mnc.product_tmpl_id
LEFT JOIN mrp_location_clientes as mlc2 ON so.id = mlc2.sale_id AND pt.id = mlc2.product_tmpl_id
LEFT JOIN mrp_planta_clientes1 as mpc1 ON so.id = mpc1.sale_id AND pt.id = mpc1.product_tmpl_id


WHERE
   PA.name->>'es_MX' = 'Color' AND mp.state = 'confirmed' 
GROUP BY
    so.name, pt.name, pc.name, slp.complete_name, EXTRACT(day FROM mp.date_planned_start), EXTRACT(month FROM mp.date_planned_start), EXTRACT(year FROM mp.date_planned_start),
    EXTRACT(day FROM so.x_studio_fecha_de_cancelacion), EXTRACT(month FROM so.x_studio_fecha_de_cancelacion), EXTRACT(year FROM so.x_studio_fecha_de_cancelacion), mp.state, code, fecha_entrega, disponibility, pt.id, so.id, mpc1.planta, referencia_cliente, mnc.note, mlc2.location
ORDER BY
    date_start
    limit 10;
            """)
            _logger.info("View mrp_stock_clientes created successfully.")
        except Exception as e:
            _logger.error("Error creating view mrp_stock_clientes: %s", e)


    def open_notes_conf(self):
        
        compose_form = self.env.ref('mrp_clientes.custom_pop_notes_wizard_view_form', raise_if_not_found=False)
        
        ctx = { 'default_stock_template_id': self.product_template_id, 'default_stock_sale_id': self.sale_id , 'default_stock_note': self.note}
        return {'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'custom.pop.notes',
                'views': [(compose_form.id, 'form')],
                'view_id': False,
                'target': 'new',
                'context': ctx,
            }

    def change_route_warehouse(self):
        compose_form = self.env.ref('mrp_clientes.custom_route_warehouse_change', raise_if_not_found=False)

        sale_order = self.env['sale.order'].search([('id','=',self.sale_id)], [])

        if sale_order and len(sale_order) == 1:
        
            ctx = { 'default_stock_route_id': sale_order.x_studio_many2one_field_t8EjK.id, 'default_stock_sale_id': self.sale_id , 'default_stock_warehouse_id': sale_order.warehouse_id.id}
            return {'type': 'ir.actions.act_window',
                    'view_mode': 'form',
                    'res_model': 'custom.route.warehouse',
                    'views': [(compose_form.id, 'form')],
                    'view_id': False,
                    'target': 'new',
                    'context': ctx,
                }


    def open_location_conf(self):
        
        compose_form = self.env.ref('mrp_clientes.custom_wizard_locationsCL_view_form', raise_if_not_found=False)
        
        ctx = { 'default_stock_template_id': self.product_template_id, 'default_stock_sale_id': self.sale_id , 'default_stock_locations': self.location_edit}
        return {'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'custom.pop.locations',
                'views': [(compose_form.id, 'form')],
                'view_id': False,
                'target': 'new',
                'context': ctx,
            }

    def open_date_conf(self):
        
        compose_form = self.env.ref('mrp_clientes.custom_date_change', raise_if_not_found=False)
        
        ctx = { 'default_stock_template_id': self.product_template_id, 'default_stock_sale_id': self.sale_id , 'default_stock_dates': self.date_start}
        return {'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'custom.date.mrpclientes',
                'views': [(compose_form.id, 'form')],
                'view_id': False,
                'target': 'new',
                'context': ctx,
            }

    def open_pproduction(self):
        
        compose_form = self.env.ref('mrp_clientes.custom_pop_planta_wizard_view_form', raise_if_not_found=False)
        
        ctx = { 'default_stock_template_id': self.product_template_id, 'default_stock_sale_id': self.sale_id , 'default_stock_planta': self.location}
        return {'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'custom.pop.planta',
                'views': [(compose_form.id, 'form')],
                'view_id': False,
                'target': 'new',
                'context': ctx,
            }

    def open_date_cita(self):
        
        compose_form = self.env.ref('mrp_clientes.custom_cita_change', raise_if_not_found=False)
        
        ctx = { 'default_stock_template_id': self.product_template_id, 'default_stock_sale_id': self.sale_id , 'default_stock_datecita': self.fecha_entrega}
        return {'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'custom.cita.mrpclientes',
                'views': [(compose_form.id, 'form')],
                'view_id': False,
                'target': 'new',
                'context': ctx,
            }