# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.tests import Form
from odoo.tools.misc import formatLang, format_date as odoo_format_date, get_lang
class MrpClientes1Planta(models.Model):
    
    _name = 'mrp.planta.clientes1'
    _description = 'Plantas P Programa clientes'

    planta = fields.Char(string='Planta')

    sale_id = fields.Integer(string='id sale')

    product_tmpl_id = fields.Integer(string='id product')