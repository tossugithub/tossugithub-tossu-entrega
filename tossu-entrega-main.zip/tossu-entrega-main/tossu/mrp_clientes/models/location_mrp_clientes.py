# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.tests import Form
from odoo.tools.misc import formatLang, format_date as odoo_format_date, get_lang
class MrpClientesLocation(models.Model):
    
    _name = 'mrp.location.clientes'
    _description = 'Ubicaciónes Programa producción'

    location = fields.Char(string='Ubicación')

    sale_id = fields.Integer(string='Id venta')

    product_tmpl_id = fields.Integer(string='Id producto padre')