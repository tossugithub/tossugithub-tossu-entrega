# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.tests import Form
from odoo.tools.misc import formatLang, format_date as odoo_format_date, get_lang
class PlLines(models.Model):
    
    _name = 'pl.lines2'
    _description = 'Programa produccion'

    product_template_id = fields.Many2one('product.template', string='Template producto')
    
    sale_id = fields.Many2one('sale.order', string='Sale Order')



