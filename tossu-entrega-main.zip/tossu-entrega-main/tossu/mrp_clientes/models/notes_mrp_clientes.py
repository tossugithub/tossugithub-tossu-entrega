# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.tests import Form
from odoo.tools.misc import formatLang, format_date as odoo_format_date, get_lang
class MrpClientesNotes1(models.Model):
    
    _name = 'mrp.notes.clientes1'
    _description = 'Notas Programa clientes'

    note = fields.Char(string='Nota')

    sale_id = fields.Integer(string='Nota')

    product_tmpl_id = fields.Integer(string='Nota')