# -*- coding: utf-8 -*-


{
    'name': 'Programa Clientes 1',
    
    'summary': """Programa clientes1""",
    
    'description': """
       App Clientes 1
        """,
    
    'author': 'Sergio',
    'category': 'manufacturing',
    'version': '0.1',
    'depends': ['base', 'stock','mrp'],
    'data':[
        'security/ir.model.access.csv',
        'views/mrp_stock_clientes_view1.xml',
        'wizard/config_wizard_note.xml',
        'wizard/config_wizard_route_warehouse.xml',
        'wizard/config_wizard_locations.xml',
        'wizard/config_wizard_date_change.xml',
        'wizard/config_wizard_planta.xml',
        'wizard/config_wizard_datecita_change.xml',

        ],
    
    'license': 'OPL-1'
}