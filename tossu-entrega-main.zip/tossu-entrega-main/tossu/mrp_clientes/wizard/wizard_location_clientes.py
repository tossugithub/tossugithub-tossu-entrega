from odoo import api, fields, models, _
import logging
_logger = logging.getLogger(__name__)

class CustomLocationCl(models.TransientModel):
    
    _name = "custom.pop.locations"

    def product_template_id(self):
        
        return self._context.get('default_stock_template_id')

    def product_template_sale(self):
        
        return self._context.get('default_stock_sale_id')

    def product_template_locations(self):
        
        return self._context.get('default_stock_locations')
        
    name = fields.Char(string='Ubicación', default=product_template_locations)

    sale_id = fields.Char(string='id sale', default=product_template_sale)

    product_tmpl_id = fields.Char(string='id product_template', default=product_template_id)


    def do_create_location(self):

        for record in self:

            loc_str = str(record.name)
            if loc_str:
    
                try:
                    loc_id = self.env['mrp.location.clientes'].search([('sale_id','=',record.sale_id),('product_tmpl_id','=',record.product_tmpl_id)], [])
        
                    if loc_id:
                        loc_id.write({'location': loc_str})
        
                    else:
                        self.env['mrp.location.clientes'].create({'location': loc_str,'sale_id': record.sale_id,'product_tmpl_id': record.product_tmpl_id})
    
                except Exception as e:
                    _logger.info(e)
        
                
        return True

    def do_delete_location(self):
        
        for record in self:
                
            if str(record.name):
                try:
                    loc_id = self.env['mrp.location.clientes'].search([('sale_id','=',record.sale_id),('product_tmpl_id','=',record.product_tmpl_id)], [])
            
                    if loc_id:
                        loc_id.write({'location': False})

        
                except Exception as e:
                        _logger.info(e)
        return True