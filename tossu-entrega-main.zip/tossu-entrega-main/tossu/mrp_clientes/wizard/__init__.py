# -*- coding: utf-8 -*-

from . import wizard_note
from . import wizard_plantaprod
from . import wizard_route_warehouse
from . import wizard_location_clientes
from . import wizard_date_change
from . import wizard_datecita_change