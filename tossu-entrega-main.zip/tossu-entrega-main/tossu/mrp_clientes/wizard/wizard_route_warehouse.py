from odoo import api, fields, models, _
import logging
_logger = logging.getLogger(__name__)

class CustomPopMessage(models.TransientModel):
    
    _name = "custom.route.warehouse"

    def route_id(self):
        
        return self._context.get('default_stock_route_id')

    def product_template_sale(self):
        
        return self._context.get('default_stock_sale_id')

    def warehouse_id(self):
        
        return self._context.get('default_stock_warehouse_id')
        
    route_id_sale = fields.Many2one('stock.route',string='Ruta ID', default=route_id)

    warehouse_id_sale = fields.Many2one('stock.warehouse',string='Almacén ID', default=warehouse_id)

    sale_id = fields.Char(string='id Venta', default=product_template_sale)


    def do_save_warehouse_route(self):

        for record in self:

            try:
                sale = self.env['sale.order'].search([('id','=',record.sale_id)], [])

                if sale and sale.mrp_production_ids:

                    for mo in sale.mrp_production_ids:
                        if mo.state != 'done' or mo.state != 'cancel':
                            mo._action_cancel()

                    sale._action_cancel()

                    sale.write({'x_studio_many2one_field_t8EjK':self.route_id_sale, 'warehouse_id': self.warehouse_id_sale})

                    sale._action_draft()
            except Exception as e:
                _logger.info(e)
                           
                
        return True