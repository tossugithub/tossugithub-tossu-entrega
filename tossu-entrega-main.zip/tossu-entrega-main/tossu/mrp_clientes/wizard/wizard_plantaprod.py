from odoo import api, fields, models, _
import logging
_logger = logging.getLogger(__name__)

class CustomPantaPC(models.TransientModel):
    
    _name = "custom.pop.planta"

    def product_template_id(self):
        
        return self._context.get('default_stock_template_id')

    def product_template_sale(self):
        
        return self._context.get('default_stock_sale_id')

    def product_template_planta(self):
        
        return self._context.get('default_stock_planta')
        
    name = fields.Char(string='Planta producción', default=product_template_planta)

    sale_id = fields.Char(string='id sale', default=product_template_sale)

    product_tmpl_id = fields.Char(string='id product_template', default=product_template_id)


    def do_create_plantaprod(self):

        for record in self:

            planta_str = str(record.name)
            if planta_str:
    
                try:
                    plp_id = self.env['mrp.planta.clientes1'].search([('sale_id','=',record.sale_id),('product_tmpl_id','=',record.product_tmpl_id)], [])
        
                    if plp_id:
                        plp_id.write({'planta': planta_str})
        
                    else:
                        self.env['mrp.planta.clientes1'].create({'planta': planta_str,'sale_id': record.sale_id,'product_tmpl_id': record.product_tmpl_id})
    
                except Exception as e:
                    _logger.info(e)
        
                
        return True

    def do_delete_plantaprod(self):
        
        for record in self:
                
            if str(record.name):
                try:
                    note_id = self.env['mrp.planta.clientes1'].search([('sale_id','=',record.sale_id),('product_tmpl_id','=',record.product_tmpl_id)], [])
            
                    if note_id:
                        note_id.write({'planta': False})

        
                except Exception as e:
                        _logger.info(e)
        return True