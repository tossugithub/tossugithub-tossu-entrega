from odoo import api, fields, models, _
import logging
_logger = logging.getLogger(__name__)
from datetime import datetime, timedelta


class CustomPopMessage(models.TransientModel):
    
    _name = "custom.date.mrpclientes"

    def _get_date_planned_start(self):
        
        default_stock_dates = self._context.get('default_stock_dates')
        if default_stock_dates:
            # Asumiendo que default_stock_dates es una cadena de fecha en formato YYYY-MM-DD
            # Puedes convertirlo a un objeto de fecha y sumar un día si es necesario
            date_planned_start = datetime.strptime(default_stock_dates, "%Y-%m-%d").date()
            # Añadir un día si es necesario
            date_planned_start += timedelta(days=1)
            _logger.info("La fecha es:")
            _logger.info(str(date_planned_start))
        
        return date_planned_start

    def product_template_sale(self):
        
        return self._context.get('default_stock_sale_id')

    date_planned_start = fields.Datetime(
        'Fecha de producción', copy=False, default=_get_date_planned_start,
        help="Fecha en la que iniciará la producción",
        index=True, required=False)

    sale_id = fields.Char(string='id Venta', default=product_template_sale)


    def do_save_date(self):

        for record in self:

            try:
                sale = self.env['sale.order'].search([('id','=',record.sale_id)], [])

                if sale and sale.mrp_production_ids:

                    for mo in sale.mrp_production_ids:
                        if mo.state == 'confirmed':
                            if record.date_planned_start:
                                mo.write({'date_planned_start': record.date_planned_start})

            except Exception as e:
                _logger.info(e)
                           
                
        return True