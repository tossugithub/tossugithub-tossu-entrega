from odoo import api, fields, models, _
import logging
_logger = logging.getLogger(__name__)

class CustomNotesC(models.TransientModel):
    
    _name = "custom.pop.notes"

    def product_template_id(self):
        
        return self._context.get('default_stock_template_id')

    def product_template_sale(self):
        
        return self._context.get('default_stock_sale_id')

    def product_template_note(self):
        
        return self._context.get('default_stock_note')
        
    name = fields.Char(string='Nota', default=product_template_note)

    sale_id = fields.Char(string='id sale', default=product_template_sale)

    product_tmpl_id = fields.Char(string='id product_template', default=product_template_id)


    def do_create_note(self):

        for record in self:

            nota_str = str(record.name)
            if nota_str:
    
                try:
                    note_id = self.env['mrp.notes.clientes1'].search([('sale_id','=',record.sale_id),('product_tmpl_id','=',record.product_tmpl_id)], [])
        
                    if note_id:
                        note_id.write({'note': nota_str})
        
                    else:
                        self.env['mrp.notes.clientes1'].create({'note': nota_str,'sale_id': record.sale_id,'product_tmpl_id': record.product_tmpl_id})
    
                except Exception as e:
                    _logger.info(e)
        
                
        return True

    def do_delete_note(self):
        
        for record in self:
                
            if str(record.name):
                try:
                    note_id = self.env['mrp.notes.clientes1'].search([('sale_id','=',record.sale_id),('product_tmpl_id','=',record.product_tmpl_id)], [])
            
                    if note_id:
                        note_id.write({'note': False})

        
                except Exception as e:
                        _logger.info(e)
        return True