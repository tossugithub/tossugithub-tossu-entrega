# -*- coding: utf-8 -*-
{
    'name': 'Engomados Masivos Auditoría Batch',
    
    'summary': """Engomados Masivos Auditoría Batch app""",
    
    'description': """
        Genera engomados masivos para auditoría Batch
        """,
    
    'author': 'Defulfillment',
    'category': 'Packaging',
    'version': '0.1',
    'depends': ['base_automation','stock'],
    'data':['views/massive_packing_views.xml',
            'wizard/config_wizard_massive.xml',
            'security/ir.model.access.csv',
        
           ],
    'license': 'OPL-1'
}