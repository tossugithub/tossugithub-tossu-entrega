from odoo import models,fields, api
from odoo.exceptions import UserError
from odoo.tools.translate import _
import logging
_logger = logging.getLogger(__name__)

class SaleOrderLineTemplate(models.Model):
    _inherit = 'stock.picking'

    compute_location_dest_id =fields.Text(
        string="name location dest id",
        store=True, readonly=False, precompute=True,
        required=False, compute='_compute_location_dest_id_name',)
    
    @api.depends('location_dest_id')
    def _compute_location_dest_id_name(self):
        for rec in self:
            if rec.location_dest_id:
                rec.compute_location_dest_id = rec.location_dest_id.name


    def open_product_conf(self):

        if len(self.move_line_ids) == 0:
            raise UserError(_('No hay productos para empaquetar'))
        
        compose_form = self.env.ref('massive_packing.config_stock_wizard', raise_if_not_found=False)
        
        ctx = { 'default_stock_picking_id': self.id  }
        return {'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'config.stock.massive.wizard',
                'views': [(compose_form.id, 'form')],
                'view_id': False,
                'target': 'new',
                'context': ctx,
            }
    
