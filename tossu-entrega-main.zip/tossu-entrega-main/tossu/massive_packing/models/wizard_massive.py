# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
import logging
import pytz
_logger = logging.getLogger(__name__)
from odoo.exceptions import UserError


class ConfigStockWizard(models.TransientModel):
    _name = "config.stock.massive.wizard"
    _description = "Sale Label Wizard"
    moves = fields.Many2one('stock.picking', string='Move')
    cajas = fields.Integer(string='Cajas', default=0)
    config_stock_wizard_lines = fields.One2many('config.stock.massive.wizard.line','config_stock_massive_wizard_id', string='Lines')
    

    @api.onchange('moves')
    def _onchange_test(self):
        _logger.info("ENTRO AQUI ONCHANGE")
        _logger.info(self._context)

    def get_id_stock_picking(self):
        _logger.info("ENTRO AQUI")
        _logger.info(self._context)
        
        return self._context.get('default_stock_picking_id')
    
    get_id_stock_picking_field = fields.Integer(string='ID Stock Picking', default=get_id_stock_picking)

    @api.model_create_multi
    def create(self, vals_list):
        _logger.info("ENTRO AQUI CREATE")
        _logger.info(vals_list)

        return super().create(vals_list)   

    @api.onchange('get_id_stock_picking_field')
    def _compute_config_stock_wizard_lines(self):
        _logger.info(self.get_id_stock_picking_field)
        list= []
        if self.get_id_stock_picking_field:

            stock_id = self.env['stock.picking'].browse(int(self.get_id_stock_picking_field))
            
            for rec in stock_id.move_line_ids:
                if rec.result_package_id:
                    continue
                self.config_stock_wizard_lines = [(0, 0, {
                    'product_id': rec.product_id.id,
                    'id_movimiento': int(rec.id),
                    'unidades': 0,
                    'qty_done': rec.reserved_uom_qty,
                })]

            if len(self.config_stock_wizard_lines) == 0:
                raise UserError(_('No hay productos para empaquetar'))

    def do_pack_massive(self):
        list_lines_to_pack = self.config_stock_wizard_lines
        _logger.info("ENTRO AQUI DO PACK MASSIVE")
        _logger.info(list_lines_to_pack)

        if self.cajas > 0:
            for i in range(self.cajas):
                for line in list_lines_to_pack:
                    _logger.info("srocks")
                    _logger.info(line.id_movimiento)
                    if line.unidades > 0:
                        self.env['stock.move.line'].browse(line.id_movimiento).write({'qty_done': line.unidades})
                        
                picking = self.env['stock.picking'].browse(int(self.get_id_stock_picking_field))
                picking.action_put_in_pack()

    def test(self):
        return True
                    
  
#Model used as line(s), to prepare products by domain wiard
#Logic taken from sale.template
class StockTemplateLine(models.TransientModel):
    _name = "config.stock.massive.wizard.line"
    _description = "Massive Template Line"

    config_stock_massive_wizard_id = fields.Many2one(
        comodel_name='config.stock.massive.wizard',
        index=True, required=True,
        ondelete='cascade', readonly=True)
    id_movimiento = fields.Integer(string='ID Movimiento', default=0)
    unidades = fields.Integer(string='Unidades', default=0)
    
    product_id = fields.Many2one('product.product', string="Product")

    name = fields.Text(
        string="Producto",
        compute='_compute_name',
        store=True, readonly=False, precompute=True,
        required=False,
        translate=True)
    
    qty_done = fields.Float(string='Reservado', required=True, default=1.0)
    
    @api.depends('product_id')
    def _compute_name(self):
        for option in self:
            if not option.product_id:
                continue
            option.name = option.product_id.get_product_multiline_description_sale()