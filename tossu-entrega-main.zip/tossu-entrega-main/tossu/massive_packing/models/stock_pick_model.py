from odoo import models, fields

class SaleOrderLineTemplate(models.Model):
    _inherit = 'stock.move.line'

    spplit = fields.Integer(string='Split', default=0)
    id_operation_type = fields.Integer(related='picking_type_id.id', string="id operation type")