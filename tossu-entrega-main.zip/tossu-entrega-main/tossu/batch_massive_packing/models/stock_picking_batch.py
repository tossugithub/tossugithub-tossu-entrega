from odoo import models,fields, api
from odoo.exceptions import UserError
from odoo.tools.translate import _
import logging
_logger = logging.getLogger(__name__)

class BatchStockPickTemplate(models.Model):
    _inherit = 'stock.picking.batch'

    def open_product_conf(self):

        if len(self.move_line_ids) == 0:
            raise UserError(_('No hay productos para empaquetar'))
        
        compose_form = self.env.ref('batch_massive_packing.config_stock_wizard', raise_if_not_found=False)
        
        ctx = { 'default_stock_picking_id': self.id  }
        return {'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'config.stock.massive.wizard.batch',
                'views': [(compose_form.id, 'form')],
                'view_id': False,
                'target': 'new',
                'context': ctx,
            }

    def action_open_packs(self):
        self.ensure_one()
        action = self.env["ir.actions.actions"]._for_xml_id("stock.action_package_view")
        packages = self.move_line_ids.mapped('result_package_id')
        action['domain'] = [('id', 'in', packages.ids)]
        action['context'] = {'picking_id': self.id}
        return action
