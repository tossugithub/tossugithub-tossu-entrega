from . import stock_picking_batch
from . import wizard_massive
