# -*- coding: utf-8 -*-


{
    'name': 'Sale Massive Import',
    
    'summary': """Sale Massive Import app""",
    
    'description': """
        Sale Massive Import
        """,
    
    'author': 'Sergio',
    'category': 'Training',
    'version': '0.1',
    'depends': ['base', 'stock', 'sale'],
    'data':[
        'security/sale_import_massive_security.xml',
        'security/ir.model.access.csv',
        'views/massive_sale_import_menuitems.xml',
        'views/sale_massive_view_import.xml',
        'views/web_template_product.xml',
        'wizard/config_wizard_success.xml'
        ],
    
    'license': 'OPL-1'
}