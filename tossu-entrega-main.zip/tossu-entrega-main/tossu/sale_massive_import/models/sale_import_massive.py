# -*- coding: utf-8 -*-
from odoo import models, fields
from odoo.exceptions import ValidationError, UserError
import base64
from odoo import _
import re
import csv
import io
import os.path
from datetime import datetime
import logging
import xlrd 
import pytz
import time
import threading
from multiprocessing import Process



_logger = logging.getLogger(__name__)
from odoo import models, fields, api, _

class MassiveImportSale(models.Model):
    
    _name = 'sale.massive.import'
    _description = 'Sale Massive Import'
    
    name = fields.Char(string='Nombre de importación', required=True, store=True, default='Nueva importación', readonly=True)
    description = fields.Text(string='Observaciones', required=False)
    
    status = fields.Selection(string='Estado',
                            selection=[('error', 'Error'),
                                       ('pass', 'Hecho'),
                                       ('process', 'Procesando')],
                            copy=False, default='process')

    
    active = fields.Boolean(string='Active', default=True)

    file = fields.Binary('Excel File', required=False)

    archivo = fields.Char(string='Title', required=False)

    sale_import_massive_lines = fields.One2many('sale.massive.import.line','sale_import_massive_id', string='Lines')

    date_done = fields.Datetime(string='Fecha de creación', required=False)

    
    def import_excel(self):

        
            self.ensure_one()
            columnas_esperadas = ["Número de orden","EAN/UPC","Descripcion","Precio Unitario","Modelo","Cantidad","Destino","Fecha Cancelación", "Tienda"]
            values = None
            pattern = re.compile(r"^(0?[1-9]|[12][0-9]|3[01])/(?:0?[1-9]|[12][0-9]|3[0-1])/\d{4}$")
            formatted_date =''
            row_values = None
            product_to_create = None
            partner_to_create = None
            partners = None
            self.sale_import_massive_lines = []
            self.status = 'process'
            
              
            try:
                xlsx_base64 = base64.b64decode(self.file)
                workbook = xlrd.open_workbook(file_contents=xlsx_base64)
                sheet = workbook.sheet_by_index(0)

                if sheet.nrows == 0:
                    self.sale_import_massive_lines = [(0, 0, {
                                'error': "Archivo vacío"
                            })]
                    return False

                if sheet.ncols == len(columnas_esperadas):
                # Obtener los nombres de las columnas del archivo
                    columnas_archivo = [sheet.cell_value(0, col) for col in range(sheet.ncols)]

                    # Verificar si los nombres de las columnas coinciden con las columnas esperadas
                    if columnas_archivo != columnas_esperadas:
                           self.status = 'error'
                           self.sale_import_massive_lines = [(0, 0, {
                                'name': "Nombre de columnas válidas: " + str(columnas_esperadas),
                                'error': "Nombre de columnas no son válidas"
                            })]
                           return False
                        
                     
                else:
                    self.sale_import_massive_lines = [(0, 0, {
                                'name': "Columnas válidas: " + str(columnas_esperadas),
                                'error': "Columnas no válidas"
                            })]
                    return False

                
                """threaded_calculation2 = threading.Thread(target=self._check_integrity(sheet, columnas_esperadas))
                threaded_calculation2.start()
                _logger.info(str(threaded_calculation2))"""
                result = self._check_integrity(sheet, columnas_esperadas)
                if result:
                    return result
                

            except Exception as e:
                _logger.info(e)
                return str(e)


            
    def _check_integrity(self, sheet, columnas_esperadas):
        values = None
        pattern = re.compile(r"^(0?[1-9]|[12][0-9]|3[01])/(?:0?[1-9]|[12][0-9]|3[0-1])/\d{4}$")
        formatted_date =''
        row_values = None
        distint_number_order = []
        sin_duplicados = []
        self.sale_import_massive_lines = [(5, 0, 0)]
        products = []
        partner_ids = []
        payload_integrity = {'integrity': False, 'products': products, 'partner_ids': partner_ids}
        partner_id_partner_invoice_and_partner_shipping = [] 
        orders_to_confirm = []
        order_to_create = []

        try:
            for row in range(1, sheet.nrows):

                if row % 1000 == 0:
                    time.sleep(3)
                    self.env.cr.commit()

                num_row = row + 1
                row_values = sheet.row_values(row)
                values = dict(zip(columnas_esperadas, row_values))
                #list.append(values)
                #self.create(values)

                if (isinstance(values['Cantidad'], float) or isinstance(values['Cantidad'], int)) and (isinstance(values['Número de orden'], float) or isinstance(values['Número de orden'], int)) and (isinstance(values['Precio Unitario'], float) or isinstance(values['Precio Unitario'], int)):
                    values['Número de orden'] = str(int(values['Número de orden']))
                
                else:
                    self.sale_import_massive_lines = [(0, 0, {
                        'name': "Línea "+ str(num_row) ,
                        'error': "Formato de datos incorrecto o faltan datos"
                    })]
                    continue
                
                if isinstance(values['EAN/UPC'], float):
                    values['EAN/UPC'] = str(int(values['EAN/UPC']))


                #partners = self.env['res.partner'].search([('name','=',str(values['Destino']))])
                partner_id_partner_invoice_and_partner_shipping = []
                query_partner = """
                            SELECT 
                                rs1.id, rs1.name    
                            FROM res_partner rs1
                            INNER JOIN res_partner as rs2 ON rs1.parent_id = rs2.id
                            where   rs1.name = '%s' and (rs2.name like 'Walmart' or rs2.name like 'walmart');
        
                        """ 
                self._cr.execute(query_partner % (str(values['Destino'])) )
                
                results_partners = self._cr.fetchall()


                if results_partners:
                    partner_id_partner_invoice_and_partner_shipping.append({'id': results_partners[0][0], 'name': results_partners[0][1]})
                
                elif len(results_partners) > 1:
                    self.sale_import_massive_lines = [(0, 0, {
                            'name': "Orden: " + str(values['Número de orden']) + " - " + "Línea "+ str(num_row) + " " + str(row_values),
                            'error': "Destino duplicado"
                        })]
                    continue
                else:
                    self.sale_import_massive_lines = [(0, 0, {
                        'name': "Orden: " + str(values['Número de orden']) + " - " + "Línea "+ str(num_row) + " " + str(row_values),
                        'error': "Destino no encontrado"
                    })]
                    continue

                query2 = """
                            SELECT id FROM sale_order
                            WHERE client_order_ref ='%s' and partner_id = %s;


                        """ 
        
                self._cr.execute(query2 % ( str(values['Número de orden']), partner_id_partner_invoice_and_partner_shipping[0]['id']))

                    
                check_exist_sale_order = self._cr.fetchall()                    

                if check_exist_sale_order:
                    distint_number_order.append(str(values['Número de orden']))
                    continue

                if isinstance(values['Fecha Cancelación'], float) or isinstance(values['Fecha Cancelación'], int):
                    datetime_date = xlrd.xldate_as_datetime(values['Fecha Cancelación'], 0) 
                    date_object = datetime_date.date() 
                    formatted_date = datetime.strptime(date_object.isoformat(), "%Y-%m-%d").strftime("%d/%m/%Y")
                            
                else:
                    if pattern.match(values['Fecha Cancelación']):
                                formatted_date = values['Fecha Cancelación']
                    else:
                        self.sale_import_massive_lines = [(0, 0, {
                                'name': "Orden: " + str(values['Número de orden']) + " - " + "Línea "+ str(num_row) + " " + str(row_values),
                                'error': "Fecha incorrecta - DD/MM/AAAA"
                        })]
                        continue 
                    try:
                            dia, mes, anio = formatted_date.split('/')
                            date_order = datetime(int(anio), int(mes), int(dia), 6, 0, 0)
                    except Exception as e:
                            self.sale_import_massive_lines = [(0, 0, {
                                'name': "Orden: " + str(values['Número de orden']) + " - " + "Línea "+ str(num_row) + " " + str(row_values),
                                'error': "Fecha incorrecta - DD/MM/AAAA"
                            })]
                            continue
                    
                #product = self.env['product.product'].search_read(['&',("x_studio_sku_1_1","=",str(values['EAN/UPC'])),("product_customer","=",str(values['Tienda']))])
                query_prod = """
                            select pp.id, pp.x_studio_sku_1_1, pc.name from product_product pp 
                            INNER JOIN product_template as pt ON pp.product_tmpl_id = pt.id 
                            INNER JOIN product_customer as pc ON pt.product_customer = pc.id 
                            where pp.x_studio_sku_1_1 = '%s' and pp.active and pc.name = '%s';
        
                        """ 
                self._cr.execute(query_prod % (str(values['EAN/UPC']), str(values['Tienda'])) )
                
                results_products = self._cr.fetchall()

                if not results_products:
                    self.sale_import_massive_lines = [(0, 0, {
                        'name': "Orden: " + str(values['Número de orden']) + " - " + "Línea "+ str(num_row) + " " + str(row_values),
                        'error': "Producto no encontrado"
                    })]
                    continue
                else:
                    if len(results_products) > 1:
                        self.sale_import_massive_lines = [(0, 0, {
                            'name': "Orden: " + str(values['Número de orden']) + " - " + "Línea "+ str(num_row) + " " + str(row_values),
                            'error': "Producto duplicado"
                        })]
                        continue
                self.env.cr.commit()
                
                products.append({'id': results_products[0][0], 'x_studio_sku_1_1': results_products[0][1], 'product_customer': str(results_products[0][2])})
                partner_ids.append({'id': partner_id_partner_invoice_and_partner_shipping[0]['id'], 'name': str(values['Destino'])})
                
                   
        except Exception as e:
            _logger.info(e) 
            self.sale_import_massive_lines = [(0, 0, {
                'name': "Error",
                'error': "Error al leer archivo - " + str(e)	
            })]


        if distint_number_order:
            sin_duplicados = list(set(distint_number_order))
            for order in sin_duplicados:
                self.sale_import_massive_lines = [(0, 0, {
                            'name': "Orden duplicada: " + str(order),
                            'error': "Orden ya existente"
                        })]
                
        if len(self.sale_import_massive_lines) == 0:
            payload_integrity['integrity'] = True
            unique_keys = {(producto['id'], producto['product_customer'], producto['x_studio_sku_1_1']) for producto in payload_integrity['products']}
            productos_sin_repetir = [
                {'id': producto[0], 'product_customer': producto[1], 'x_studio_sku_1_1': producto[2]} for producto in unique_keys
            ]
            payload_integrity['products'] = productos_sin_repetir
            payload_integrity['partner_ids'] = list({v['name']:v for v in partner_ids}.values()) 
        else:
            self.status = 'error'
        
        if payload_integrity['integrity'] == False:
            return {
            'name': 'Error',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'custom.pop.message',
            'target':'new',
            'context':{'default_name':"No se pudo realizar la importación. Verifique el registro"} 
            }

        for row in range(1, sheet.nrows):
            
            num_row = row + 1
            row_values = sheet.row_values(row)
            values = dict(zip(columnas_esperadas, row_values))
            exists = False

            try:

                if isinstance(values['EAN/UPC'], float):
                    values['EAN/UPC'] = str(int(values['EAN/UPC']))

                for product in payload_integrity['products']:
                    if product['x_studio_sku_1_1'] == str(values['EAN/UPC']) and product['product_customer'] == str(values['Tienda']):
                        product_to_create = {'product_id': product['id'], 'product_uom_qty': values['Cantidad'], 'price_unit': values['Precio Unitario'], 'name': values['Descripcion'], 'x_studio_modelo': values['Modelo'], 'x_studio_fecha_cancelacion': formatted_date, 'x_studio_sku_1_1': values['EAN/UPC'], 'x_studio_tienda': values['Tienda']}
                        break
                    
                
                for partner in payload_integrity['partner_ids']:
                    if partner['name'] == str(values['Destino']):
                        partner_to_create = partner['id']
                        break
    

                if isinstance(values['Fecha Cancelación'], float) or isinstance(values['Fecha Cancelación'], int):
                    datetime_date = xlrd.xldate_as_datetime(values['Fecha Cancelación'], 0) 
                    date_object = datetime_date.date() 
                    formatted_date = datetime.strptime(date_object.isoformat(), "%Y-%m-%d").strftime("%d/%m/%Y")
                            
                else:
                    formatted_date = values['Fecha Cancelación']

                dia, mes, anio = formatted_date.split('/')
                date_order = datetime(int(anio), int(mes), int(dia), 6, 0, 0)


            except Exception as e:
                _logger.info("ERROR CON IMP")
                _logger.info(str(e))
            


            if not order_to_create:

                order_to_create.append(
                        {
                                    'client_order_ref': str(int(values['Número de orden'])),
                                    'partner_id': partner_to_create,
                                    'warehouse_id': 10,
                                    'partner_invoice_id': partner_to_create,
                                    'partner_shipping_id': partner_to_create,
                                    'x_studio_fecha_de_cancelacion': date_order,
                                    'check_confirm_sale': True,
                                    'order_line': [(0,0,{
                                            'product_id': product_to_create['product_id'],
                                            'product_uom_qty': values['Cantidad'],
                                            'price_unit': values['Precio Unitario'],
                                            'name': values['Descripcion'],
                                        })]
                                    }
                    )
            
            else:
    
                for index, order in enumerate(order_to_create):

                    if order['client_order_ref'] == str(int(values['Número de orden'])) and order['partner_id'] == partner_to_create:
                        exists = True
                        indice = index
                        break
                
                if exists:
                        
                    for index, orde_l in enumerate(order_to_create[indice]['order_line']):
                            
                        if orde_l[2]['product_id'] == product_to_create['product_id']:
                            exists_line = True
                            index_line = index
                            break
                        else:
                            exists_line = False

                    
                    if exists_line:
                        
                        order_to_create[indice]['order_line'][index_line][2]['product_uom_qty'] += int(values['Cantidad'])
                            
                        
                    else:
                        order_to_create[indice]['order_line'].append( (0,0,{
                                'product_id': product_to_create['product_id'],
                                'product_uom_qty': values['Cantidad'],
                                'price_unit': values['Precio Unitario'],
                                'name': values['Descripcion'],
                            }))
                        
                        
                else:
                    order_to_create.append(
                        {
                                    'client_order_ref': str(int(values['Número de orden'])),
                                    'partner_id': partner_to_create,
                                    'warehouse_id': 10,
                                    'partner_invoice_id': partner_to_create,
                                    'partner_shipping_id': partner_to_create,
                                    'x_studio_fecha_de_cancelacion': date_order,
                                    'check_confirm_sale': True,
                                    'order_line': [(0,0,{
                                            'product_id': product_to_create['product_id'],
                                            'product_uom_qty': values['Cantidad'],
                                            'price_unit': values['Precio Unitario'],
                                            'name': values['Descripcion'],
                                        })]
                                    }
                    )
    

        try:
              
            orders = self._run_delayed_calculations(order_to_create)
                       
        except Exception as e:
            _logger(str(e))
            self.sale_import_massive_lines = [(0, 0, {
                        'name': "Error al crear",
                        'error': " ERROR"
                    })]

            
        if len(self.sale_import_massive_lines) == 0:
            #for saleOrder in orders_to_confirm:
                #saleOrder.action_confirm()
            self.status = 'pass'
            self.file = False
            fecha_original = datetime.now()
            zona_horaria_local = pytz.timezone('America/Mexico_City')
            # Convertir la fecha original a un objeto datetime con la zona horaria del servidor
            fecha_original.strftime("%d/%m/%Y")
            fecha_original = pytz.utc.localize(fecha_original) 
            # Convertir la fecha a la zona horaria local
            fecha_local = fecha_original.astimezone(zona_horaria_local)
            fecha_local_objeto_datetime = datetime.strptime(fecha_local.strftime('%Y-%m-%d %H:%M:%S'), '%Y-%m-%d %H:%M:%S')

            self.sale_import_massive_lines = [(0, 0, {
                        'name': "Importación realizada exitosamente el día " + str(fecha_local), 
                    })]
            self.date_done = fecha_local_objeto_datetime
            return {
            'name': 'Hecho',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'custom.pop.message',
            'target':'new',
            'context':{'default_name':"Importación realizada exitosamente."} 
            }
            
        else:
            self.status = 'error'
            self.name='Error - ' + str(self.archivo)
            return {
            'name': 'Importación con errores',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'custom.pop.message',
            'target':'new',
            'context':{'default_name':"Revise el registro."} 
            }

        
    def _run_delayed_calculations(self, order_data):
        # sleeping time to make sure quantity done is already saved
        time.sleep(3)
        #_logger.info(order_data)
        orden_total = self.env['sale.order'].create(order_data)
        #orden_total.write({'x_studio_many2one_field_t8EjK': 70})
        #orden_total.action_confirm()
        self.env.cr.commit()
        for order in orden_total:
            order.write({'x_studio_many2one_field_t8EjK': 70})
            #order.action_confirm()

        return orden_total
    

    def _run_confirm_orders(self, orders):
        _logger.info("entro en confirm")
        for record in orders:
            self.with_delay().tu_funcion(record)

    def tu_funcion(self, record_id):
        _logger.info("Confimado")
        record_id.action_confirm()
        _logger.info("Confimado")




    
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _("Nueva importación")) == _("Nueva importación"):
                seq_date = fields.Datetime.context_timestamp(
                    self, fields.Datetime.to_datetime(vals['create_date'])
                ) if 'date_order' in vals else None
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'sale.massive.import', sequence_date=seq_date) or _("Nueva importación")

        return super(MassiveImportSale, self).create(vals)
        

        
class SaleMassiveLine(models.Model):
    _name = "sale.massive.import.line"
    _description = "Lines Error of Sale Massive Import"

    sale_import_massive_id = fields.Many2one(
        comodel_name='sale.massive.import',
        index=True, required=True,
        ondelete='cascade', readonly=True)

    name = fields.Text(string='Registro y linea', required=False)

    error = fields.Text(string='Error', required=False)


class SaleInheritCron(models.Model):
    _inherit = "sale.order"

    check_confirm_sale = fields.Boolean(string='Es confirmada?', required=False, default=False)

    def perform_background_task(self):
        for sales in self.env["sale.order"].search(['&',('check_confirm_sale','=',True), ('state','=','draft')]):
            sales.action_confirm()
            sales.check_confirm_sale = False
            self.env.cr.commit()

