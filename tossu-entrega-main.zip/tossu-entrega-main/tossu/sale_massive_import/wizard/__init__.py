# -*- coding: utf-8 -*-

from . import wizard_success_msg