from odoo import api, fields, models, _

class CustomPopMessage(models.TransientModel):
    
    _name = "custom.pop.message"

    name = fields.Char('Message')