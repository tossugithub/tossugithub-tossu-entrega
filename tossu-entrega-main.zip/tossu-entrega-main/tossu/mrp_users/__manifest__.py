{
    'name': 'MRP user groups',
    'version': '1.0',
    'author': 'Tecnicora',
    'summary': 'Genera los grupos para Programa de Produccion y otros de MRP',
    'license': 'AGPL-3',
    'depends': ['base', 'stock','product','uom','barcodes','delivery','mrp','purchase','purchase_stock','sale','sale_stock'],  # List of dependencies
    'data': [
        'security/mrp_users_security.xml',
        'security/ir.model.access.csv',
        'views/mrp_users_views.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
